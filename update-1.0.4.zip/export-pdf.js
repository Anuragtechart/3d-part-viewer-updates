// Component-list PDF report: cover, group views with callouts, parts list (BOM), component detail pages.
import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

const NAVY = [30, 41, 59], GREY = [100, 108, 120], LIGHT = [210, 214, 220];
const GROUP_COLORS = [0x9aa7b5, 0x6b7a8c, 0x3fa66b, 0xe58a2d, 0x8467c7, 0x3b3f46, 0x2f8fd8, 0xd9528a, 0xb5a642, 0x2fb5b0];
const PW = 210, PH = 297, M = 15;
const clean = s => String(s ?? '').replace(/[^\x20-\xFF]/g, '?');
const hex = c => [(c >> 16) & 255, (c >> 8) & 255, c & 255];
const tick = () => new Promise(r => setTimeout(r, 0));

// Part boxes come from the raw geometry (what the offscreen scene draws), never from viewer state.
let gi = new Map();
function ginfo(p) {
  let r = gi.get(p);
  if (!r) {
    const g = p.mesh.geometry; if (!g.boundingBox) g.computeBoundingBox();
    r = {c: g.boundingBox.getCenter(new THREE.Vector3()), s: g.boundingBox.getSize(new THREE.Vector3())};
    gi.set(p, r);
  }
  return r;
}

const quatOfDeg = r => new THREE.Quaternion().setFromEuler(new THREE.Euler(r.x * Math.PI / 180, r.y * Math.PI / 180, r.z * Math.PI / 180, 'XYZ'));
// Same pipeline as the viewer: part spin about its own centre + explode offset, then assembly rotation about the assembly centre.
function partMatrix(p, V) {
  if (!V) return new THREE.Matrix4();
  const c0 = ginfo(p).c;
  const off = c0.clone().sub(V.P).multiplyScalar(V.k * 1.2);
  const qp = quatOfDeg(V.rots.get(p) || {x: 0, y: 0, z: 0});
  const T = (x, y, z) => new THREE.Matrix4().makeTranslation(x, y, z);
  const Mp = T(c0.x + off.x, c0.y + off.y, c0.z + off.z).multiply(new THREE.Matrix4().makeRotationFromQuaternion(qp)).multiply(T(-c0.x, -c0.y, -c0.z));
  const Ma = T(V.P.x, V.P.y, V.P.z).multiply(new THREE.Matrix4().makeRotationFromQuaternion(V.Qa)).multiply(T(-V.P.x, -V.P.y, -V.P.z));
  return Ma.multiply(Mp);
}

// ---------------- offscreen renderer ----------------
let ex = null;
function getEx() {
  if (ex) return ex;
  const renderer = new THREE.WebGLRenderer({antialias: true, preserveDrawingBuffer: true});
  renderer.setPixelRatio(1);
  renderer.setClearColor(0xffffff, 1);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const scene = new THREE.Scene();
  scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
  const light = new THREE.DirectionalLight(0xffffff, 1.4);
  const group = new THREE.Group();
  scene.add(light, light.target, group);
  const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 1e6);
  camera.up.set(0, 0, 1);
  ex = {renderer, scene, light, group, camera};
  return ex;
}

// items: [{p, color, ghost, edges}]; fit: parts that define the framing; dir: view direction
const EDGE_CACHE = new WeakMap();
function edgeGeo(g) { if (g.userData && g.userData.edgeGeo) return g.userData.edgeGeo; let e = EDGE_CACHE.get(g); if (!e) { e = new THREE.EdgesGeometry(g, 28); EDGE_CACHE.set(g, e); } return e; }
function shot(items, fit, dir, w, h, V) {
  const {renderer, scene, light, group, camera} = getEx();
  renderer.setSize(w, h, false);
  const made = [];
  for (const it of items) {
    const mat = new THREE.MeshStandardMaterial({
      polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1,
      color: it.color, metalness: 0.15, roughness: 0.65, side: THREE.DoubleSide,
      transparent: true, opacity: it.ghost ? 0.13 : 1, depthWrite: !it.ghost,
    });
    const m = new THREE.Mesh(it.p.mesh.geometry, mat);
    m.matrixAutoUpdate = false; m.matrix.copy(partMatrix(it.p, V)); m.matrixWorldNeedsUpdate = true;
    m.renderOrder = it.ghost ? 0 : 1; // ghosts first, highlighted parts always drawn over them
    group.add(m); made.push(m);
    if (it.edges) {
      const e = new THREE.LineSegments(edgeGeo(it.p.mesh.geometry), new THREE.LineBasicMaterial({color: 0x222222}));
      e.matrixAutoUpdate = false; e.matrix.copy(partMatrix(it.p, V)); e.matrixWorldNeedsUpdate = true;
      e.renderOrder = 2; group.add(e); made.push(e);
    }
  }
  const box = new THREE.Box3();
  for (const p of fit) {
    const q = ginfo(p), M = partMatrix(p, V);
    for (let i = 0; i < 8; i++) {
      box.expandByPoint(new THREE.Vector3(q.c.x + (i & 1 ? 1 : -1) * q.s.x / 2, q.c.y + (i & 2 ? 1 : -1) * q.s.y / 2, q.c.z + (i & 4 ? 1 : -1) * q.s.z / 2).applyMatrix4(M));
    }
  }
  const c = box.getCenter(new THREE.Vector3());
  const r = Math.max(box.getSize(new THREE.Vector3()).length() / 2, 1e-3);
  const d = new THREE.Vector3(...dir).normalize();
  const dist = r / Math.sin(THREE.MathUtils.degToRad(camera.fov / 2)) * 0.95;
  camera.aspect = w / h;
  camera.position.copy(c).addScaledVector(d, dist);
  camera.near = Math.max(dist - r * 3, r * 0.01); camera.far = dist + r * 3;
  camera.lookAt(c); camera.updateProjectionMatrix(); camera.updateMatrixWorld(true);
  light.position.copy(camera.position).add(new THREE.Vector3(r, -r, r)); light.target.position.copy(c);
  renderer.render(scene, camera);
  const url = renderer.domElement.toDataURL('image/jpeg', 0.86);
  const pts = new Map();
  for (const it of items) {
    const v = ginfo(it.p).c.clone().applyMatrix4(partMatrix(it.p, V)).project(camera);
    pts.set(it.p, [v.x * 0.5 + 0.5, 1 - (v.y * 0.5 + 0.5)]);
  }
  for (const m of made) {
    group.remove(m);
    if (m.material) m.material.dispose();

  }
  return {url, pts};
}

// ---------------- data model ----------------
function fmtDim(v) { return v >= 10 ? String(Math.round(v)) : String(Math.round(v * 10) / 10); }
function metrics(p) {
  const g = p.mesh.geometry, pos = g.attributes.position, idx = g.index;
  const n = idx ? idx.count : pos.count;
  let V = 0, A = 0;
  for (let i = 0; i < n; i += 3) {
    const ia = idx ? idx.getX(i) : i, ib = idx ? idx.getX(i + 1) : i + 1, ic = idx ? idx.getX(i + 2) : i + 2;
    const ax = pos.getX(ia), ay = pos.getY(ia), az = pos.getZ(ia);
    const bx = pos.getX(ib), by = pos.getY(ib), bz = pos.getZ(ib);
    const cx = pos.getX(ic), cy = pos.getY(ic), cz = pos.getZ(ic);
    V += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
    const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
    A += Math.hypot(uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx) / 2;
  }
  return {V: Math.abs(V), A};
}
const baseName = s => String(s).replace(/(?:[\s_\-:]+\d{1,3}|\s*<\d+>|\s*\(\d+\))$/, '').trim() || String(s);

export function buildModel(ctx) {
  gi = new Map();
  const {parts, treeRoot} = ctx;
  const gOf = new Map(), order = [], groups = [];
  const add = (p, g) => { gOf.set(p, g); order.push(p); if (!groups.includes(g)) groups.push(g); };
  const leaves = (n, out = []) => { if (n.part) out.push(n.part); (n.children || []).forEach(k => leaves(k, out)); return out; };
  for (const c of (treeRoot && treeRoot.children) || []) {
    if (c.part) add(c.part, 'Parts'); else leaves(c).forEach(p => add(p, c.name || 'Assembly'));
  }
  if (!order.length) parts.forEach(p => add(p, 'Parts'));
  const map = new Map();
  for (const p of order) {
    const gs = ginfo(p).s, ext = [gs.x, gs.y, gs.z].sort((a, b) => b - a);
    const key = baseName(p.name) + '|' + ext.map(v => Math.round(v * 2) / 2).join(',') + '|' + Math.round(p.tris);
    let L = map.get(key);
    if (!L) {
      const {V, A} = metrics(p);
      const t = A > 0 ? 2 * V / A : 0;
      const fill = ext[0] * ext[1] * ext[2] > 0 ? V / (ext[0] * ext[1] * ext[2]) : 1;
      const sheet = t > 0.05 && t <= 8 && t <= 0.15 * ext[1] && (ext[2] <= 1.3 * t + 0.4 || fill < 0.25);
      L = {key, name: baseName(p.name), group: gOf.get(p), parts: [], ext, spec: sheet ? 'Sheet approx. ' + (Math.round(t * 10) / 10) + ' mm' : '-', t: sheet ? t : 0};
      map.set(key, L);
    }
    L.parts.push(p);
  }
  const lines = [...map.values()].sort((a, b) => groups.indexOf(a.group) - groups.indexOf(b.group));
  lines.forEach((L, i) => { L.no = i + 1; L.size = L.ext.map(fmtDim).join(' x '); });
  return {lines, groups, nBodies: order.length};
}

// ---------------- PDF ----------------
export async function buildPdf(ctx, opts, progress = () => {}) {
  gi = new Map();
  const {jsPDF} = window.jspdf;
  const doc = new jsPDF({unit: 'mm', format: 'a4', orientation: 'portrait'});
  const {lines, groups, nBodies} = buildModel(ctx);
  const allParts = ctx.parts;
  const multi = groups.length > 1;
  const title = clean(opts.title || 'Assembly');
  const fileExt = (ctx.file.ext || 'model').toUpperCase();
  const colOf = (p, L) => multi ? GROUP_COLORS[groups.indexOf(L.group) % GROUP_COLORS.length] : p.color.getHex();
  const colByPart = new Map();
  lines.forEach(L => L.parts.forEach(p => colByPart.set(p, colOf(p, L))));
  const ISO = [1, -1.25, 0.9];
  let V = null, VDIR = ISO, VOPP = null;
  if (opts.useSaved && ctx.view) {
    const ub0 = new THREE.Box3();
    allParts.forEach(p => { const q = ginfo(p); ub0.expandByPoint(q.c.clone().addScaledVector(q.s, 0.5)); ub0.expandByPoint(q.c.clone().addScaledVector(q.s, -0.5)); });
    V = {P: ub0.getCenter(new THREE.Vector3()), Qa: quatOfDeg(ctx.view.rotA), k: ctx.view.k || 0, rots: ctx.view.rots};
    VDIR = ctx.view.dir; VOPP = [-VDIR[0], -VDIR[1], VDIR[2]];
  }
  let section = 0;
  const total = (opts.cover ? 2 : 0) + (opts.groups ? lines.length / 6 + groups.length : 0) + (opts.details ? lines.length * 1 : 0) + 1;
  let doneUnits = 0;
  const step = async (msg, u = 1) => { doneUnits += u; progress(msg, Math.min(0.98, doneUnits / total)); await tick(); };

  const heading = (text, y = M + 6) => { doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(...NAVY); doc.text(clean(text), M, y); };
  const para = (text, x, y, w, size = 8.5, color = GREY) => {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(size); doc.setTextColor(...color);
    const ls = doc.splitTextToSize(clean(text), w); doc.text(ls, x, y); return y + ls.length * (size * 0.42);
  };
  let first = true;
  const newPage = () => { if (first) first = false; else doc.addPage(); };

  // ----- cover -----
  if (opts.cover) {
    newPage();
    doc.setFont('helvetica', 'bold'); doc.setFontSize(20); doc.setTextColor(...NAVY); doc.text(title, M, 24);
    doc.setFontSize(11); doc.text(`Component identification from ${fileExt} file  (${clean(ctx.file.name)})`, M, 32);
    const ub = new THREE.Box3(); allParts.forEach(p => { const q = ginfo(p); ub.expandByPoint(q.c.clone().addScaledVector(q.s, 0.5)); ub.expandByPoint(q.c.clone().addScaledVector(q.s, -0.5)); });
    const s = ub.getSize(new THREE.Vector3());
    let y = para(`Overall body about ${Math.round(s.x)} W x ${Math.round(s.y)} D x ${Math.round(s.z)} H mm. ${lines.length} components, ${nBodies} solid bodies. ` +
      `All images on the following pages are rendered directly from the model geometry. Sheet thickness is estimated from the model ` +
      `(2 x volume / surface area). Component names come from the file.`, M, 39, PW - 2 * M);
    await step('Rendering overview…');
    const fi = allParts.map(p => ({p, color: colByPart.get(p) ?? p.color.getHex(), edges: true}));
    const fv = shot(fi, allParts, V ? VDIR : [0.5, -1, 0.35], 640, 480, V);
    const bv = shot(fi, allParts, V ? VOPP : [-0.5, 1, 0.35], 640, 480, V);
    const iw = 87, ih = 65.25, iy = y + 6;
    doc.addImage(fv.url, 'JPEG', M, iy, iw, ih); doc.addImage(bv.url, 'JPEG', M + iw + 6, iy, iw, ih);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(...NAVY);
    doc.text(V ? 'Saved view' : 'Front view', M, iy + ih + 5); doc.text(V ? 'Opposite view' : 'Back view', M + iw + 6, iy + ih + 5);
    if (multi) {
      let ly = iy + ih + 18;
      doc.setFontSize(11); doc.text('Groups used in this document', M, ly); ly += 6;
      groups.forEach((g, gi) => {
        const cnt = lines.filter(L => L.group === g).reduce((a, L) => a + L.parts.length, 0);
        doc.setFillColor(...hex(GROUP_COLORS[gi % GROUP_COLORS.length])); doc.rect(M, ly - 3.2, 5, 4, 'F');
        doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(40, 40, 40);
        doc.text(`${clean(g)} (${cnt} pcs)`, M + 8, ly); ly += 5.6;
      });
    }
  }

  // ----- group views -----
  if (opts.groups) {
    for (let gi = 0; gi < groups.length; gi++) {
      const gl = lines.filter(L => L.group === groups[gi]);
      const CH = 24;
      section++;
      for (let c0 = 0, ci = 0; c0 < gl.length; c0 += CH, ci++) {
        const chunk = gl.slice(c0, c0 + CH);
        await step(`Rendering view ${gi + 1}/${groups.length}…`, 1);
        newPage();
        heading(`${section}. ${groups[gi]}${ci ? ' (cont.)' : ''}`);
        para('Numbers match the parts list. Red dot marks the part.', M, M + 12, PW - 2 * M);
        const inChunk = new Set(chunk.flatMap(L => L.parts));
        const items = allParts.map(p => inChunk.has(p) ? {p, color: colByPart.get(p) ?? p.color.getHex(), edges: true} : {p, color: 0xaeb6c0, ghost: true});
        const fit = [...inChunk];
        const sh = shot(items, fit, VDIR, 900, 900, V);
        const iw = 150, ix = (PW - iw) / 2, iy = 34;
        doc.addImage(sh.url, 'JPEG', ix, iy, iw, iw);
        const pts = chunk.map(L => { const q = sh.pts.get(L.parts[0]); return {no: L.no, x: ix + q[0] * iw, y: iy + q[1] * iw}; });
        const cx = ix + iw / 2, left = [], right = [];
        pts.forEach(t => (t.x < cx ? left : right).push(t));
        for (const side of [left, right]) {
          side.sort((a, b) => a.y - b.y);
          let prev = iy - 4;
          side.forEach(t => { t.cy = Math.max(t.y, prev + 7); prev = t.cy; });
          if (side.length) { const over = side[side.length - 1].cy - (iy + iw); if (over > 0) side.forEach(t => t.cy -= over); }
        }
        const drawSide = (side, ccx) => side.forEach(t => {
          doc.setDrawColor(130, 136, 146); doc.setLineWidth(0.2);
          const dx = ccx - t.x, dy = t.cy - t.y, dl = Math.hypot(dx, dy) || 1;
          doc.line(t.x, t.y, ccx - dx / dl * 3.2, t.cy - dy / dl * 3.2);
          doc.setFillColor(211, 47, 47); doc.circle(t.x, t.y, 0.9, 'F');
          doc.setFillColor(255, 255, 255); doc.setDrawColor(...NAVY); doc.setLineWidth(0.3); doc.circle(ccx, t.cy, 3.2, 'FD');
          doc.setFont('helvetica', 'bold'); doc.setFontSize(7); doc.setTextColor(...NAVY); doc.text(String(t.no), ccx, t.cy + 1, {align: 'center'});
        });
        drawSide(left, ix - 6); drawSide(right, ix + iw + 6);
        // legend
        let ly = iy + iw + 10; const colW = (PW - 2 * M) / 2;
        doc.setFontSize(8); chunk.forEach((L, i) => {
          const col = i % 2, row = Math.floor(i / 2);
          if (col === 0 && row === 0) ly = iy + iw + 10;
          doc.setFont('helvetica', 'bold'); doc.setTextColor(...NAVY); doc.text(String(L.no), M + col * colW, ly + row * 4.6);
          doc.setFont('helvetica', 'normal'); doc.setTextColor(40, 40, 40);
          doc.text(clean(L.name + (L.parts.length > 1 ? `  (x${L.parts.length})` : '')), M + col * colW + 8, ly + row * 4.6);
        });
      }
    }
  }

  // ----- BOM -----
  if (opts.bom) {
    section++;
    await step('Building parts list…');
    const cols = [['No.', 10], ['Component', 58], ['Group', 30], ['Qty', 10], ['Size (mm, extents)', 34], ['Material / spec', 38]];
    const xs = []; let acc = M; cols.forEach(c => { xs.push(acc); acc += c[1]; });
    const header = y => {
      doc.setFillColor(238, 240, 244); doc.rect(M, y, PW - 2 * M, 7, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(...NAVY);
      cols.forEach((c, i) => doc.text(c[0], xs[i] + 1.5, y + 4.8));
      return y + 7;
    };
    newPage(); heading(`${section}. Parts list (BOM)`);
    let y = header(M + 11);
    for (const L of lines) {
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
      const cells = [String(L.no), L.name, L.group, String(L.parts.length), L.size, L.spec].map((t, i) => doc.splitTextToSize(clean(t), cols[i][1] - 3));
      const rh = Math.max(7, Math.max(...cells.map(c => c.length)) * 3.6 + 3.2);
      if (y + rh > PH - 18) { doc.addPage(); heading(`${section}. Parts list (BOM) - cont.`); y = header(M + 11); doc.setFont('helvetica', 'normal'); doc.setFontSize(8); }
      doc.setTextColor(30, 30, 30);
      cells.forEach((c, i) => doc.text(c, xs[i] + 1.5, y + 4.6));
      doc.setDrawColor(...LIGHT); doc.setLineWidth(0.15); doc.line(M, y + rh, PW - M, y + rh);
      y += rh;
    }
    para('Size = bounding box extents of one piece, largest to smallest. Sheet thickness is estimated from the model for thin parts only.', M, y + 6, PW - 2 * M, 7.5);
  }

  // ----- detail pages -----
  if (opts.details) {
    section++;
    newPage(); heading(`${section}. Component detail pages`);
    para('Left image: the part alone. Right image: its position in the machine (red = this part).', M, M + 12, PW - 2 * M);
    let y = M + 20, curGroup = null;
    const CARD = 40, GAP = 3;
    for (let i = 0; i < lines.length; i++) {
      const L = lines[i];
      await step(`Detail pages ${i + 1}/${lines.length}…`, 1);
      const needHead = multi && L.group !== curGroup;
      if (y + (needHead ? 9 : 0) + CARD > PH - 16) { doc.addPage(); y = M + 4; }
      if (needHead) { curGroup = L.group; doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(...NAVY); doc.text(clean(L.group), M, y + 4); y += 9; }
      const p0 = L.parts[0];
      const a = shot([{p: p0, color: colByPart.get(p0), edges: true}], [p0], VDIR, 480, 360, V);
      const inL = new Set(L.parts);
      const b = shot(allParts.map(p => inL.has(p) ? {p, color: 0xd32f2f, edges: true} : {p, color: 0xaeb6c0, ghost: true}), allParts, VDIR, 480, 360, V);
      doc.setDrawColor(...LIGHT); doc.setLineWidth(0.3); doc.roundedRect(M, y, PW - 2 * M, CARD, 1.5, 1.5, 'S');
      doc.addImage(a.url, 'JPEG', M + 3, y + 5, 40, 30); doc.addImage(b.url, 'JPEG', M + 46, y + 5, 40, 30);
      const tx = M + 92;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...NAVY);
      let tl = doc.splitTextToSize(`${L.no}. ${clean(L.name)}`, PW - M - tx - 3);
      if (tl.length > 2) { tl = tl.slice(0, 2); tl[1] = tl[1].replace(/.{0,2}$/, '') + '...'; }
      doc.text(tl, tx, y + 9);
      const y0 = y + 9 + (tl.length - 1) * 4.4;
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(50, 50, 50);
      doc.text(`Qty: ${L.parts.length}`, tx, y0 + 7);
      doc.text(`Size: ${L.size} mm`, tx, y0 + 12.5);
      doc.text(`Spec: ${clean(L.spec)}`, tx, y0 + 18);
      if (multi) doc.text(`Group: ${clean(L.group)}`, tx, y0 + 23.5);
      y += CARD + GAP;
    }
  }

  // ----- footer -----
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) {
    doc.setPage(i); doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(130, 136, 146);
    doc.text(`${title} - component list from ${fileExt} file`, M, PH - 8);
    doc.text(`Page ${i}`, PW - M, PH - 8, {align: 'right'});
  }
  progress('Done', 1);
  return {blob: doc.output('blob'), pages: n, lines: lines.length, bodies: nBodies};
}
