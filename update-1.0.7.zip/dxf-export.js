// Laser-cut DXF export: unfolds each sheet-metal part (bends developed with a K-factor) into a flat pattern.
import {buildModel} from './export-pdf.js';
import {zipSync, strToU8} from 'three/addons/libs/fflate.module.js';

const STD_T = [0.5, 0.6, 0.8, 1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8];
export const snapT = t => { for (const s of STD_T) if (Math.abs(t - s) <= 0.07 * s) return s; return Math.round(t * 10) / 10; };

// ---------- mesh -> welded triangles ----------
function weld(g) {
  const pos = g.attributes.position, idx = g.index;
  const n = pos.count, cell = 0.01, map = new Map(), vid = new Int32Array(n), pts = [];
  const key = (x, y, z) => x + ',' + y + ',' + z;
  for (let i = 0; i < n; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const cx = Math.round(x / cell), cy = Math.round(y / cell), cz = Math.round(z / cell);
    let found = -1;
    for (let dx = -1; dx <= 1 && found < 0; dx++) for (let dy = -1; dy <= 1 && found < 0; dy++) for (let dz = -1; dz <= 1; dz++) {
      const k = map.get(key(cx + dx, cy + dy, cz + dz));
      if (k !== undefined) { const p = pts[k]; if (Math.abs(p[0] - x) < 0.008 && Math.abs(p[1] - y) < 0.008 && Math.abs(p[2] - z) < 0.008) { found = k; break; } }
    }
    if (found < 0) { found = pts.length; pts.push([x, y, z]); map.set(key(cx, cy, cz), found); }
    vid[i] = found;
  }
  const tris = [], cnt = idx ? idx.count : n;
  for (let i = 0; i < cnt; i += 3) {
    const a = vid[idx ? idx.getX(i) : i], b = vid[idx ? idx.getX(i + 1) : i + 1], c = vid[idx ? idx.getX(i + 2) : i + 2];
    if (a !== b && b !== c && a !== c) tris.push([a, b, c]);
  }
  return {pts, tris};
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const len = a => Math.hypot(a[0], a[1], a[2]);

// ---------- unfold ----------
export function unfold(g, tEst, K, flip = false) {
  const {pts, tris} = weld(g);
  const nT = tris.length; if (!nT) throw new Error('no triangles');
  const N = new Array(nT), AR = new Float64Array(nT), C = new Array(nT);
  let vol = 0;
  for (let i = 0; i < nT; i++) {
    const [a, b, c] = tris[i], A = pts[a], B = pts[b], Cc = pts[c];
    const cr = cross(sub(B, A), sub(Cc, A)), l = len(cr);
    AR[i] = l / 2; N[i] = l > 0 ? [cr[0] / l, cr[1] / l, cr[2] / l] : [0, 0, 1];
    C[i] = [(A[0] + B[0] + Cc[0]) / 3, (A[1] + B[1] + Cc[1]) / 3, (A[2] + B[2] + Cc[2]) / 3];
    vol += dot(A, cross(B, Cc)) / 6;
  }
  if (vol < 0) { for (let i = 0; i < nT; i++) { const tr = tris[i]; [tr[1], tr[2]] = [tr[2], tr[1]]; N[i] = N[i].map(v => -v); } }
  const ek = (a, b) => a < b ? a * 4194304 + b : b * 4194304 + a;
  const E = new Map();
  tris.forEach((tr, i) => { for (let k = 0; k < 3; k++) { const key = ek(tr[k], tr[(k + 1) % 3]); (E.get(key) || E.set(key, []).get(key)).push(i); } });
  // seed: biggest planar normal cluster
  const cl = new Map();
  for (let i = 0; i < nT; i++) { const k = N[i].map(v => Math.round(v * 50)).join(','); const o = cl.get(k) || {a: 0, best: i}; o.a += AR[i]; if (AR[i] > AR[o.best]) o.best = i; cl.set(k, o); }
  let seed = 0, bestA = -1; for (const o of cl.values()) if (o.a > bestA) { bestA = o.a; seed = o.best; }
  if (flip) { let b2 = -1, s2 = seed; for (let i = 0; i < nT; i++) if (dot(N[i], N[seed]) < -0.999 && AR[i] > b2) { b2 = AR[i]; s2 = i; } seed = s2; }
  // sheet thickness: ray from the seed face through the material to the opposite face
  const hit = (T) => {
    const o = C[T], d = N[T].map(v => -v); let best = Infinity;
    for (let j = 0; j < nT; j++) {
      if (j === T || dot(N[j], N[T]) > -0.9) continue;
      const [a, b, c] = tris[j], A = pts[a], e1 = sub(pts[b], A), e2 = sub(pts[c], A), h = cross(d, e2), det = dot(e1, h);
      if (Math.abs(det) < 1e-12) continue;
      const f = 1 / det, sv = sub(o, A), u = f * dot(sv, h); if (u < 0 || u > 1) continue;
      const q = cross(sv, e1), v = f * dot(d, q); if (v < 0 || u + v > 1) continue;
      const tt = f * dot(e2, q); if (tt > 0.05 && tt < best) best = tt;
    }
    return best;
  };
  const cand = [...Array(nT).keys()].filter(i => dot(N[i], N[seed]) > 0.999).sort((a, b) => AR[b] - AR[a]).slice(0, 7);
  const hs = cand.map(hit).filter(v => isFinite(v) && v < 30).sort((a, b) => a - b);
  const t = hs.length ? hs[Math.floor(hs.length / 2)] : tEst;
  // region grow + unfold in one BFS
  const COS = Math.cos(60 * Math.PI / 180);
  const raw = new Array(nT).fill(null), off = new Array(nT).fill(null), inR = new Uint8Array(nT);
  const place = (T, p3, q3, r3, p2, q2, away) => { // third vertex position from lengths
    const dpq = Math.hypot(q2[0] - p2[0], q2[1] - p2[1]);
    const lp = len(sub(r3, p3)), lq = len(sub(r3, q3));
    const x = (lp * lp - lq * lq + dpq * dpq) / (2 * dpq), h = Math.sqrt(Math.max(lp * lp - x * x, 0));
    const ux = (q2[0] - p2[0]) / dpq, uy = (q2[1] - p2[1]) / dpq;
    const nx = -uy * away, ny = ux * away;
    return [p2[0] + ux * x + nx * h, p2[1] + uy * x + ny * h];
  };
  {
    const [a, b, c] = tris[seed], A = pts[a], B = pts[b], Cc = pts[c];
    const ab = len(sub(B, A)), p2 = [0, 0], q2 = [ab, 0];
    raw[seed] = new Map([[a, p2], [b, q2], [c, place(seed, A, B, Cc, p2, q2, 1)]]);
    off[seed] = [0, 0]; inR[seed] = 1;
  }
  const queue = [seed]; let bendAngle = 0; const cross2 = [];
  for (let qi = 0; qi < queue.length; qi++) {
    const T = queue[qi], tr = tris[T];
    for (let k = 0; k < 3; k++) {
      const p = tr[k], q = tr[(k + 1) % 3], r0 = tr[(k + 2) % 3];
      const nb = E.get(ek(p, q)); if (nb.length !== 2) continue;
      const U = nb[0] === T ? nb[1] : nb[0]; if (inR[U]) continue;
      const cs = dot(N[T], N[U]); if (cs < COS) continue;
      const tu = tris[U], r = tu.find(v => v !== p && v !== q);
      const rp = raw[T].get(p), rq = raw[T].get(q), rr0 = raw[T].get(r0);
      const side = (rq[0] - rp[0]) * (rr0[1] - rp[1]) - (rq[1] - rp[1]) * (rr0[0] - rp[0]);
      const away = side > 0 ? -1 : 1;
      const r2 = place(U, pts[p], pts[q], pts[r], rp, rq, away);
      raw[U] = new Map([[p, rp], [q, rq], [r, r2]]);
      // micro-bend: shift everything beyond this edge by the neutral-axis correction
      const phi = Math.acos(Math.min(1, Math.max(-1, cs)));
      let o = off[T];
      if (phi > 0.005) {
        const conv = dot(sub(N[U], N[T]), sub(C[U], C[T])) > 0;
        const d = conv ? -phi * (1 - K) * t : phi * K * t;
        const ex = rq[0] - rp[0], ey = rq[1] - rp[1], el = Math.hypot(ex, ey);
        const px = -ey / el * away, py = ex / el * away;
        const om = [o[0] + px * d / 2, o[1] + py * d / 2];
        cross2.push({a: [rp[0] + om[0], rp[1] + om[1]], b: [rq[0] + om[0], rq[1] + om[1]], conv, phi});
        o = [o[0] + px * d, o[1] + py * d]; bendAngle += phi;
      }
      off[U] = o; inR[U] = 1; queue.push(U);
    }
  }
  // boundary loops
  const starts = new Map(), edges = [];
  for (const T of queue) {
    const tr = tris[T];
    for (let k = 0; k < 3; k++) {
      const p = tr[k], q = tr[(k + 1) % 3], nb = E.get(ek(p, q));
      const other = nb.find(u => u !== T);
      if (other !== undefined && inR[other]) continue;
      const o = off[T], P = raw[T].get(p), Q = raw[T].get(q);
      const e = {p, q, a: [P[0] + o[0], P[1] + o[1]], b: [Q[0] + o[0], Q[1] + o[1]], used: false};
      edges.push(e); (starts.get(p) || starts.set(p, []).get(p)).push(e);
    }
  }
  const loops = [];
  for (const e0 of edges) {
    if (e0.used) continue;
    const pl = []; let e = e0, guard = 0, closed = false;
    while (e && !e.used && guard++ < 1e6) {
      e.used = true; pl.push(e.a);
      const nx = (starts.get(e.q) || []).find(x => !x.used) || null;
      if (nx === null) { pl.push(e.b); closed = e.q === e0.p; break; }
      if (Math.hypot(nx.a[0] - e.b[0], nx.a[1] - e.b[1]) > 1e-4) pl.push(e.b);
      if (nx === e0) { closed = true; break; }
      e = nx;
    }
    if (pl.length >= 3) loops.push({pts: pl, closed});
  }
  let ua = 0, ta = 0; for (const T of queue) ua += AR[T]; for (let i = 0; i < nT; i++) ta += AR[i];
  const top = [...queue].sort((a, b) => AR[b] - AR[a]).slice(0, 25), hts = top.map(hit);
  const consist = hts.filter(h => isFinite(h) && Math.abs(h - t) <= 0.2 * t).length / Math.max(1, hts.length);
  return {loops, bends: bendLines(cross2), bendAngle, nTri: nT, used: queue.length, cover: ua / (ta / 2), t, vol: Math.abs(vol), ua, consist};
}

// ---------- bend lines: merge the facet edges of each bend into one line ----------
function bendLines(cr) {
  const cls = [];
  for (const c of cr) {
    const dx = c.b[0] - c.a[0], dy = c.b[1] - c.a[1], L = Math.hypot(dx, dy); if (L < 1e-6) continue;
    let ang = Math.atan2(dy, dx); if (ang < 0) ang += Math.PI; if (ang >= Math.PI) ang -= Math.PI;
    const found = cls.find(k => k.conv === c.conv && Math.min(Math.abs(k.ang - ang), Math.PI - Math.abs(k.ang - ang)) < 0.035 &&
      k.items.some(m => Math.abs(m.perp - ((c.a[0] + c.b[0]) / 2 * -Math.sin(k.ang) + (c.a[1] + c.b[1]) / 2 * Math.cos(k.ang))) < 6 &&
        Math.min(m.s1, (c.a[0] + c.b[0]) / 2 * Math.cos(k.ang) + (c.a[1] + c.b[1]) / 2 * Math.sin(k.ang) + L / 2) - Math.max(m.s0, (c.a[0] + c.b[0]) / 2 * Math.cos(k.ang) + (c.a[1] + c.b[1]) / 2 * Math.sin(k.ang) - L / 2) > -0.5));
    const k = found || (cls.push({ang, conv: c.conv, items: [], phi: 0}), cls[cls.length - 1]);
    const ca = Math.cos(k.ang), sa = Math.sin(k.ang);
    const sA = c.a[0] * ca + c.a[1] * sa, sB = c.b[0] * ca + c.b[1] * sa;
    k.items.push({perp: (c.a[0] + c.b[0]) / 2 * -sa + (c.a[1] + c.b[1]) / 2 * ca, s0: Math.min(sA, sB), s1: Math.max(sA, sB)});
    k.phi += c.phi;
  }
  return cls.filter(k => k.phi > 0.1).map(k => {
    const ca = Math.cos(k.ang), sa = Math.sin(k.ang);
    const perp = k.items.reduce((a, m) => a + m.perp, 0) / k.items.length;
    const s0 = Math.min(...k.items.map(m => m.s0)), s1 = Math.max(...k.items.map(m => m.s1));
    const pmin = Math.min(...k.items.map(m => m.perp)), pmax = Math.max(...k.items.map(m => m.perp));
    return {a: [s0 * ca - perp * sa, s0 * sa + perp * ca], b: [s1 * ca - perp * sa, s1 * sa + perp * ca], up: !k.conv, deg: k.phi * 180 / Math.PI, ba: pmax - pmin};
  });
}

// ---------- 2D helpers ----------
export const area2 = p => { let s = 0; for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; };
export function simplify(p, tol = 0.0005) {
  let pts = p.filter((v, i) => { const w = p[(i + 1) % p.length]; return Math.hypot(v[0] - w[0], v[1] - w[1]) > 1e-4; });
  let ch = true;
  while (ch && pts.length > 3) {
    ch = false; const out = [];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[(i + pts.length - 1) % pts.length], b = pts[i], c = pts[(i + 1) % pts.length];
      const l = Math.hypot(c[0] - a[0], c[1] - a[1]);
      const d = l > 0 ? Math.abs((c[0] - a[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (c[1] - a[1])) / l : 0;
      if (d < tol && ((b[0] - a[0]) * (c[0] - b[0]) + (b[1] - a[1]) * (c[1] - b[1])) > 0) { ch = true; continue; }
      out.push(b);
    }
    pts = out;
  }
  return pts;
}
export function asCircle(p) {
  if (p.length < 8) return null;
  let cx = 0, cy = 0; p.forEach(v => { cx += v[0]; cy += v[1]; }); cx /= p.length; cy /= p.length;
  const rs = p.map(v => Math.hypot(v[0] - cx, v[1] - cy)), r = rs.reduce((a, b) => a + b, 0) / rs.length;
  if (r < 0.2 || Math.max(...rs.map(x => Math.abs(x - r))) > 0.012 * r + 0.02) return null;
  return {cx, cy, r};
}
export function orient(loops, bends = []) {
  const outer = loops.reduce((a, b) => Math.abs(area2(a.pts)) >= Math.abs(area2(b.pts)) ? a : b);
  let best = {a: 0, area: Infinity};
  for (let a = 0; a < 90; a += 1) {
    const c = Math.cos(a * Math.PI / 180), s = Math.sin(a * Math.PI / 180);
    let x0 = 1e18, x1 = -1e18, y0 = 1e18, y1 = -1e18;
    for (const v of outer.pts) { const x = v[0] * c + v[1] * s, y = -v[0] * s + v[1] * c; x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    const ar = (x1 - x0) * (y1 - y0); if (ar < best.area - 1e-6) best = {a, area: ar};
  }
  const c = Math.cos(best.a * Math.PI / 180), s = Math.sin(best.a * Math.PI / 180);
  const rot = v => [v[0] * c + v[1] * s, -v[0] * s + v[1] * c];
  let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18;
  loops.forEach(l => l.pts.forEach(p => { const v = rot(p); x0 = Math.min(x0, v[0]); y0 = Math.min(y0, v[1]); x1 = Math.max(x1, v[0]); y1 = Math.max(y1, v[1]); }));
  const swap = x1 - x0 < y1 - y0;
  let ox = x0, oy = y0;
  if (swap) { ox = y0; oy = -x1; }
  const tf = p => { let v = rot(p); if (swap) v = [v[1], -v[0]]; return [v[0] - ox, v[1] - oy]; };
  return {loops: loops.map(l => ({...l, pts: l.pts.map(tf)})), bends: bends.map(k => ({...k, a: tf(k.a), b: tf(k.b)})), w: swap ? y1 - y0 : x1 - x0, h: swap ? x1 - x0 : y1 - y0};
}

// ---------- turn runs of short segments into true arcs (bulge) ----------
function circ3(a, b, c) {
  const d = 2 * (a[0] * (b[1] - c[1]) + b[0] * (c[1] - a[1]) + c[0] * (a[1] - b[1]));
  if (Math.abs(d) < 1e-9) return null;
  const a2 = a[0] * a[0] + a[1] * a[1], b2 = b[0] * b[0] + b[1] * b[1], c2 = c[0] * c[0] + c[1] * c[1];
  const x = (a2 * (b[1] - c[1]) + b2 * (c[1] - a[1]) + c2 * (a[1] - b[1])) / d, y = (a2 * (c[0] - b[0]) + b2 * (a[0] - c[0]) + c2 * (b[0] - a[0])) / d;
  return {x, y, r: Math.hypot(a[0] - x, a[1] - y)};
}
export function fitArcs(pts0, tol = 0.04) {
  let pts = pts0.slice();
  const n0 = pts.length;
  if (n0 > 1 && Math.hypot(pts[0][0] - pts[n0 - 1][0], pts[0][1] - pts[n0 - 1][1]) < 1e-6) pts.pop();
  const n = pts.length;
  if (n < 5) return pts.map(p => ({x: p[0], y: p[1], b: 0}));
  // start at the longest edge (a straight run) so arcs are not split at the start of the list
  let bi = 0, bl = -1;
  for (let i = 0; i < n; i++) { const L = Math.hypot(pts[(i + 1) % n][0] - pts[i][0], pts[(i + 1) % n][1] - pts[i][1]); if (L > bl) { bl = L; bi = i; } }
  const P = []; for (let i = 0; i <= n; i++) P.push(pts[(bi + i) % n]);
  const out = []; let i = 0;
  const okRun = (i, j) => {
    const mid = Math.round((i + j) / 2), c = circ3(P[i], P[mid], P[j]);
    if (!c || c.r > 4000 || c.r < 0.05) return null;
    let sg = 0;
    for (let k = i; k <= j; k++) if (Math.abs(Math.hypot(P[k][0] - c.x, P[k][1] - c.y) - c.r) > tol + 0.0005 * c.r) return null;
    let sweep = 0, dmin = 1e9, dmax = 0;
    for (let k = i; k < j; k++) {
      const a1 = Math.atan2(P[k][1] - c.y, P[k][0] - c.x), a2 = Math.atan2(P[k + 1][1] - c.y, P[k + 1][0] - c.x);
      let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
      if (Math.abs(d) > 1.2) return null;
      const s = Math.sign(d); if (s === 0) return null; if (sg && s !== sg) return null; sg = s; sweep += d;
      dmin = Math.min(dmin, Math.abs(d)); dmax = Math.max(dmax, Math.abs(d));
    }
    if (dmax > 2.2 * dmin) return null;
    if (Math.abs(sweep) > 6.0) return null;
    return {sweep, r: c.r};
  };
  while (i < n) {
    let bestJ = -1, best = null;
    for (let j = i + 3; j <= n; j++) { const r = okRun(i, j); if (r) { bestJ = j; best = r; } else if (bestJ >= 0) break; else if (j > i + 5) break; }
    if (bestJ >= 0 && Math.abs(best.sweep) >= 0.12 && best.r * (1 - Math.cos(Math.abs(best.sweep) / 2)) >= 0.1) {
      out.push({x: P[i][0], y: P[i][1], b: Math.tan(best.sweep / 4)}); i = bestJ;
    } else { out.push({x: P[i][0], y: P[i][1], b: 0}); i++; }
  }
  // straight stretches: remove the many tiny zig-zag points left by bend zones (0.03 mm tolerance)
  const rdp = (pp, eps) => {
    if (pp.length < 3) return pp.map((_, i) => i);
    const keep = new Array(pp.length).fill(false); keep[0] = keep[pp.length - 1] = true;
    const st = [[0, pp.length - 1]];
    while (st.length) {
      const [i0, i1] = st.pop(); let md = 0, mi = -1;
      const A = pp[i0], B = pp[i1], L = Math.hypot(B.x - A.x, B.y - A.y) || 1e-9;
      for (let t = i0 + 1; t < i1; t++) { const d = Math.abs((B.x - A.x) * (A.y - pp[t].y) - (A.x - pp[t].x) * (B.y - A.y)) / L; if (d > md) { md = d; mi = t; } }
      if (md > eps && mi > 0) { keep[mi] = true; st.push([i0, mi], [mi, i1]); }
    }
    return keep.map((k, i) => k ? i : -1).filter(i => i >= 0);
  };
  const res = [], nn = out.length; let k = 0;
  while (k < nn) {
    if (out[k].b !== 0) { res.push(out[k]); k++; continue; }
    let e = k; while (e < nn && out[e].b === 0) e++;
    const run = out.slice(k, Math.min(e, nn - 1) + 1), virt = e >= nn;
    if (virt) run.push(out[0]);
    const idx = rdp(run, 0.03);
    for (const i of idx) { if (i === run.length - 1 && (virt || e < nn)) continue; res.push(run[i]); }
    k = e;
  }
  return res;
}

// ---------- DXF writer (R12: opens everywhere) ----------
class Dxf {
  constructor() { this.e = []; }
  g(c, v) { return c + '\n' + v + '\n'; }
  layerOf(l) { return this.g(8, l); }
  poly(pts, dx, dy, layer) {
    let s = this.g(0, 'POLYLINE') + this.layerOf(layer) + this.g(66, 1) + this.g(70, 1);
    for (const p of fitArcs(pts)) s += this.g(0, 'VERTEX') + this.layerOf(layer) + this.g(10, (p.x + dx).toFixed(4)) + this.g(20, (p.y + dy).toFixed(4)) + this.g(30, 0) + (p.b ? this.g(42, p.b.toFixed(6)) : '');
    this.e.push(s + this.g(0, 'SEQEND') + this.layerOf(layer));
  }
  line(a, b, dx, dy, layer) { this.e.push(this.g(0, 'LINE') + this.layerOf(layer) + this.g(10, (a[0] + dx).toFixed(4)) + this.g(20, (a[1] + dy).toFixed(4)) + this.g(30, 0) + this.g(11, (b[0] + dx).toFixed(4)) + this.g(21, (b[1] + dy).toFixed(4)) + this.g(31, 0)); }
  circle(c, dx, dy, layer) { this.e.push(this.g(0, 'CIRCLE') + this.layerOf(layer) + this.g(10, (c.cx + dx).toFixed(4)) + this.g(20, (c.cy + dy).toFixed(4)) + this.g(30, 0) + this.g(40, c.r.toFixed(4))); }
  text(x, y, h, str, layer) { this.e.push(this.g(0, 'TEXT') + this.layerOf(layer) + this.g(10, x.toFixed(3)) + this.g(20, y.toFixed(3)) + this.g(30, 0) + this.g(40, h) + this.g(1, String(str).replace(/[^\x20-\x7e]/g, '?'))); }
  str() {
    const lay = (n, c, lt = 'CONTINUOUS') => this.g(0, 'LAYER') + this.g(2, n) + this.g(70, 0) + this.g(62, c) + this.g(6, lt);
    return this.g(0, 'SECTION') + this.g(2, 'HEADER') + this.g(9, '$ACADVER') + this.g(1, 'AC1009') + this.g(9, '$INSUNITS') + this.g(70, 4) + this.g(0, 'ENDSEC') +
      this.g(0, 'SECTION') + this.g(2, 'TABLES') + this.g(0, 'TABLE') + this.g(2, 'LTYPE') + this.g(70, 2) + this.g(0, 'LTYPE') + this.g(2, 'CONTINUOUS') + this.g(70, 0) + this.g(3, 'Solid line') + this.g(72, 65) + this.g(73, 0) + this.g(40, 0) + this.g(0, 'LTYPE') + this.g(2, 'HIDDEN') + this.g(70, 0) + this.g(3, 'Hidden') + this.g(72, 65) + this.g(73, 2) + this.g(40, 1.905) + this.g(49, 1.27) + this.g(49, -0.635) + this.g(0, 'ENDTAB') +
      this.g(0, 'TABLE') + this.g(2, 'LAYER') + this.g(70, 4) + lay('0', 7) + lay('UP', 3, 'HIDDEN') + lay('DOWN', 1, 'HIDDEN') + lay('INFO', 8) + this.g(0, 'ENDTAB') + this.g(0, 'ENDSEC') +
      this.g(0, 'SECTION') + this.g(2, 'ENTITIES') + this.e.join('') + this.g(0, 'ENDSEC') + this.g(0, 'EOF');
  }
}
function draw(d, pat, dx, dy) {
  for (const l of pat.loops) { const c = asCircle(l.pts); if (c) d.circle(c, dx, dy, '0'); else d.poly(l.pts, dx, dy, '0'); }
  for (const k of pat.bends) d.line(k.a, k.b, dx, dy, k.up ? 'UP' : 'DOWN');
}

// ---------- main ----------
const tDir = t => 't' + String(+(+t).toFixed(2)) + 'mm';
export async function buildDxfPack(ctx, opts = {}, progress = () => {}) {
  const K = opts.k ?? 0.33, {lines} = buildModel(ctx);
  const sheet = lines.filter(L => L.t > 0);
  if (!sheet.length) throw new Error('No sheet-metal parts were found in this model.');
  const files = {}, rows = [], pats = [], skipped = [];
  let i = 0;
  for (const L of sheet) {
    progress(`Unfolding ${++i}/${sheet.length}: ${L.name}`, i / sheet.length);
    await new Promise(r => setTimeout(r, 0));
    const qty = L.parts.length;
    try {
      const mp = makePattern(L.parts[0].mesh.geometry, L.t, K, !!opts.flip);
      if (mp.solid) { skipped.push(L.name + ' (' + mp.reason + ')'); continue; }
      const u0 = unfold(L.parts[0].mesh.geometry, L.t, K, !!opts.flip), t = snapT(u0.t);
      const u = Math.abs(t - u0.t) > 1e-6 ? unfold(L.parts[0].mesh.geometry, t, K, !!opts.flip) : u0;
      const loops = u.loops.filter(l => l.pts.length >= 3).map(l => ({...l, pts: simplify(l.pts)})).filter(l => l.pts.length >= 3);
      if (!loops.length) throw new Error('no outline');
      const pat = orient(loops, u.bends), nUp = pat.bends.filter(k => k.up).length, nDown = pat.bends.length - nUp;
      const warn = [];
      if (loops.some(l => !l.closed)) warn.push('open outline');
      if (u.cover < 0.7) warn.push('only part of the sheet surface could be unfolded - check');
      const safe = (L.no + '_' + L.name).replace(/[^\w\-]+/g, '_').replace(/_+/g, '_').slice(0, 60);
      const d = new Dxf(); draw(d, pat, 0, 0);
      d.text(0, -12, 6, `${L.no} ${L.name} | t=${t} mm | qty ${qty} | ${pat.w.toFixed(1)} x ${pat.h.toFixed(1)}`, 'INFO');
      files[`${tDir(t)}/${safe}_t${t}_x${qty}.dxf`] = strToU8(d.str());
      pats.push({L, pat, t, qty});
      rows.push([L.no, L.name, t, qty, pat.w.toFixed(1), pat.h.toFixed(1), loops.length - 1, nUp, nDown, warn.join('; ')]);
    } catch (err) { rows.push([L.no, L.name, t, qty, '', '', '', '', '', 'FAILED: ' + err.message]); }
  }
  if (!pats.length) throw new Error('No real sheet-metal parts found (solid or machined parts are skipped).');
  // one combined layout file per thickness, parts laid out in rows
  const byT = new Map(); for (const q of pats) { if (!byT.has(q.t)) byT.set(q.t, []); byT.get(q.t).push(q); }
  for (const [t, list] of byT) {
    const all = new Dxf(); let x = 0, y = 0, rowH = 0; const W = 2400, gap = 25;
    for (const {L, pat, qty} of list.sort((a, b) => b.pat.h - a.pat.h)) {
      if (x > 0 && x + pat.w > W) { x = 0; y += rowH + gap + 15; rowH = 0; }
      draw(all, pat, x, y); all.text(x, y - 10, 5, `${L.no} ${L.name} t${t} x${qty}`, 'INFO');
      x += pat.w + gap; rowH = Math.max(rowH, pat.h);
    }
    files[`${tDir(t)}/ALL_${tDir(t)}_layout.dxf`] = strToU8(all.str());
  }
  const head = 'No;Name;Thickness mm;Qty;Flat width mm;Flat height mm;Holes/cutouts;Bends UP;Bends DOWN;Notes';
  files['README_parts.csv'] = strToU8([head, ...rows.map(r => r.join(';'))].join('\r\n'));
  files['README.txt'] = strToU8(
    `Laser-cut flat patterns from "${opts.title || ctx.file.name}"\r\n` +
    `Units: mm. Layer 0 = cut lines (outline + holes). Layer UP (green, dashed) = bend line, bends toward you. Layer DOWN (red, dashed) = bend line, bends away from you. Layer INFO = label text only, do not cut.\r\n` +
    `UP/DOWN is as seen when you look at the DXF; use the 'flip side' option if your first bend face is the other one.\r\nBends are unfolded on the neutral axis with K-factor ${K}. Thickness is estimated from the model (2 x volume / area) and snapped to a standard gauge.\r\n` +
    `Please verify thickness, K-factor and the flat size against your bending table before cutting.\r\n` +
    (skipped.length ? `Skipped, not sheet metal: ${skipped.join('; ')}\r\n` : '') + `One folder per sheet thickness (e.g. t1.5mm, t2mm). Inside: one DXF per part type (qty in the file name), plus ALL_..._layout.dxf with all parts of that thickness in one file.\r\n`);
  const zip = zipSync(files, {level: 6});
  return {blob: new Blob([zip], {type: 'application/zip'}), count: pats.length, total: sheet.length, skipped: skipped.length, rows};
}

// one call: unfold + clean + orient a part into a flat pattern
export function makePattern(geom, tEst, K, flip) {
  const u0 = unfold(geom, tEst, K, !!flip), t = snapT(u0.t);
  const u = Math.abs(t - u0.t) > 1e-6 ? unfold(geom, t, K, !!flip) : u0;
  const loops = u.loops.filter(l => l.pts.length >= 3).map(l => ({...l, pts: simplify(l.pts)})).filter(l => l.pts.length >= 3);
  if (!loops.length) throw new Error('no outline');
  // is this really sheet metal? constant thickness, one side covers most of the surface, volume = area x thickness
  const why = [];
  if (u.cover < 0.6) why.push('surface not a single sheet side');
  if (u.consist < 0.75) why.push('thickness not constant');
  if (u.vol > 0 && Math.abs(u.vol - u.ua * t) / u.vol > 0.25) why.push('volume does not match a sheet');
  if (u.bends.length > 80) why.push('too many bends');
  if (why.length) return {solid: true, reason: why.join(', ')};
  return {pat: orient(loops, u.bends), t, cover: u.cover};
}
