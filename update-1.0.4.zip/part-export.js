// Export a single part: STEP (faceted B-rep), STL (binary), OBJ, and a DXF flat pattern for sheet-metal parts.
import {makePattern, asCircle} from './dxf-export.js';

function tris(geom) {
  const pos = geom.attributes.position, idx = geom.index, n = idx ? idx.count : pos.count, out = [];
  for (let i = 0; i < n; i += 3) {
    const t = [0, 1, 2].map(k => idx ? idx.getX(i + k) : i + k);
    out.push(t.map(v => [pos.getX(v), pos.getY(v), pos.getZ(v)]));
  }
  return out;
}
const safe = s => String(s || 'part').replace(/[^\w\-. ]+/g, '_').trim() || 'part';

export function partStl(geom, name) {
  const T = tris(geom), buf = new ArrayBuffer(84 + T.length * 50), dv = new DataView(buf);
  const hd = ('Part ' + safe(name)).slice(0, 79); for (let i = 0; i < hd.length; i++) dv.setUint8(i, hd.charCodeAt(i));
  dv.setUint32(80, T.length, true);
  let o = 84;
  for (const [a, b, c] of T) {
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; const l = Math.hypot(...n) || 1; n = n.map(x => x / l);
    for (const x of [...n, ...a, ...b, ...c]) { dv.setFloat32(o, x, true); o += 4; }
    dv.setUint16(o, 0, true); o += 2;
  }
  return new Blob([buf], {type: 'model/stl'});
}

export function partObj(geom, name) {
  const pos = geom.attributes.position, idx = geom.index; let s = 'o ' + safe(name) + '\n';
  for (let i = 0; i < pos.count; i++) s += `v ${pos.getX(i).toFixed(5)} ${pos.getY(i).toFixed(5)} ${pos.getZ(i).toFixed(5)}\n`;
  const n = idx ? idx.count : pos.count;
  for (let i = 0; i < n; i += 3) s += `f ${(idx ? idx.getX(i) : i) + 1} ${(idx ? idx.getX(i + 1) : i + 1) + 1} ${(idx ? idx.getX(i + 2) : i + 2) + 1}\n`;
  return new Blob([s], {type: 'text/plain'});
}

// STEP AP214, planar-face B-rep (every mesh triangle becomes one planar face). Opens as a solid body in SolidWorks, FreeCAD, Fusion, Inventor.
export function partStep(geom, name) {
  const nm = safe(name).replace(/'/g, ''), T = tris(geom), lines = []; let id = 0;
  const add = s => { lines.push(`#${++id}=${s};`); return id; };
  const f = x => (Math.abs(x) < 1e-9 ? 0 : x).toFixed(5);
  const app = add("APPLICATION_CONTEXT('core data for automotive mechanical design processes')");
  add(`APPLICATION_PROTOCOL_DEFINITION('international standard','automotive_design',2000,#${app})`);
  const pctx = add(`PRODUCT_CONTEXT('',#${app},'mechanical')`), prod = add(`PRODUCT('${nm}','${nm}','',(#${pctx}))`);
  add(`PRODUCT_RELATED_PRODUCT_CATEGORY('part',$,(#${prod}))`);
  const form = add(`PRODUCT_DEFINITION_FORMATION('','',#${prod})`), dctx = add(`PRODUCT_DEFINITION_CONTEXT('part definition',#${app},'design')`);
  const pdef = add(`PRODUCT_DEFINITION('design','',#${form},#${dctx})`), pds = add(`PRODUCT_DEFINITION_SHAPE('','',#${pdef})`);
  const lu = add('(LENGTH_UNIT() NAMED_UNIT(*) SI_UNIT(.MILLI.,.METRE.))'), au = add('(NAMED_UNIT(*) PLANE_ANGLE_UNIT() SI_UNIT($,.RADIAN.))'), su = add('(NAMED_UNIT(*) SI_UNIT($,.STERADIAN.) SOLID_ANGLE_UNIT())');
  const unc = add(`UNCERTAINTY_MEASURE_WITH_UNIT(LENGTH_MEASURE(1.E-05),#${lu},'distance_accuracy_value','')`);
  const ctx = add(`(GEOMETRIC_REPRESENTATION_CONTEXT(3) GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT((#${unc})) GLOBAL_UNIT_ASSIGNED_CONTEXT((#${lu},#${au},#${su})) REPRESENTATION_CONTEXT('',''))`);
  let vol = 0; for (const [a, b, c] of T) vol += (a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0])) / 6;
  const pts = new Map(), vps = new Map(), ecs = new Map(), P = [];
  const vp = p => { const k = p.map(f).join(','); let v = vps.get(k); if (!v) { const c = add(`CARTESIAN_POINT('',(${p.map(f).join(',')}))`); v = {id: add(`VERTEX_POINT('',#${c})`), c, p, n: P.length}; P.push(v); vps.set(k, v); } return v; };
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], nrm = v => { const l = Math.hypot(...v); return l ? v.map(x => x / l) : v; };
  const edge = (u, v) => { const lo = u.n < v.n ? u : v, hi = lo === u ? v : u, k = lo.n + '_' + hi.n; let e = ecs.get(k);
    if (!e) { const d = sub(hi.p, lo.p), L = Math.hypot(...d), dir = add(`DIRECTION('',(${nrm(d).map(f).join(',')}))`), vec = add(`VECTOR('',#${dir},${L.toFixed(5)})`), ln = add(`LINE('',#${lo.c},#${vec})`); e = add(`EDGE_CURVE('',#${lo.id},#${hi.id},#${ln},.T.)`); ecs.set(k, e); }
    return add(`ORIENTED_EDGE('',*,*,#${e},${u === lo ? '.T.' : '.F.'})`); };
  const faces = [];
  for (let [a, b, c] of T) {
    if (vol < 0) [b, c] = [c, b];
    const n = cr(sub(b, a), sub(c, a)); if (Math.hypot(...n) < 1e-9) continue;
    const A = vp(a), B = vp(b), C = vp(c); if (A === B || B === C || A === C) continue;
    const oe = [edge(A, B), edge(B, C), edge(C, A)], loop = add(`EDGE_LOOP('',(${oe.map(x => '#' + x).join(',')}))`), bound = add(`FACE_OUTER_BOUND('',#${loop},.T.)`);
    const nd = add(`DIRECTION('',(${nrm(n).map(f).join(',')}))`), rd = add(`DIRECTION('',(${nrm(sub(b, a)).map(f).join(',')}))`), ax = add(`AXIS2_PLACEMENT_3D('',#${A.c},#${nd},#${rd})`), pl = add(`PLANE('',#${ax})`);
    faces.push(add(`ADVANCED_FACE('',(#${bound}),#${pl},.T.)`));
  }
  const shell = add(`CLOSED_SHELL('',(${faces.map(x => '#' + x).join(',')}))`), brep = add(`MANIFOLD_SOLID_BREP('${nm}',#${shell})`);
  const org = add("CARTESIAN_POINT('',(0.,0.,0.))"), dz = add("DIRECTION('',(0.,0.,1.))"), dx = add("DIRECTION('',(1.,0.,0.))");
  const ax = add(`AXIS2_PLACEMENT_3D('',#${org},#${dz},#${dx})`);
  const sr = add(`SHAPE_REPRESENTATION('${nm}',(#${ax},#${brep}),#${ctx})`);
  add(`SHAPE_DEFINITION_REPRESENTATION(#${pds},#${sr})`);
  const head = `ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('Part ${nm} (planar-face B-rep)'),'2;1');\nFILE_NAME('${nm}.step','${new Date().toISOString().slice(0, 19)}',(''),(''),'3D Part Viewer','3D Part Viewer','');\nFILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));\nENDSEC;\nDATA;\n`;
  return new Blob([head + lines.join('\n') + '\nENDSEC;\nEND-ISO-10303-21;\n'], {type: 'application/step'});
}

// DXF flat pattern of one sheet-metal part (throws if the part is not sheet metal)
export function partFlatDxf(geom, name, k = 0.33) {
  let best = null;
  for (const flip of [false, true]) { try { const r = makePattern(geom, 2, k, flip); if (r.pat && (!best || r.pat.loops.length > best.pat.loops.length)) best = r; } catch (e) {} }
  if (!best) throw new Error('This part is not sheet metal, so there is no flat pattern.');
  const pat = best.pat, g = (c, v) => c + '\n' + v + '\n', e = [];
  const ent = (ty, l) => g(0, ty) + g(8, l);
  for (const l of pat.loops) {
    const c = asCircle(l.pts);
    if (c) e.push(ent('CIRCLE', '0') + g(10, c.cx.toFixed(4)) + g(20, c.cy.toFixed(4)) + g(30, 0) + g(40, c.r.toFixed(4)));
    else { let s = ent('POLYLINE', '0') + g(66, 1) + g(70, 1); for (const p of l.pts) s += ent('VERTEX', '0') + g(10, p[0].toFixed(4)) + g(20, p[1].toFixed(4)) + g(30, 0); e.push(s + ent('SEQEND', '0')); }
  }
  for (const b of pat.bends) e.push(ent('LINE', b.up ? 'UP' : 'DOWN') + g(10, b.a[0].toFixed(4)) + g(20, b.a[1].toFixed(4)) + g(30, 0) + g(11, b.b[0].toFixed(4)) + g(21, b.b[1].toFixed(4)) + g(31, 0));
  const lay = (n, c, lt) => g(0, 'LAYER') + g(2, n) + g(70, 0) + g(62, c) + g(6, lt);
  const dxf = g(0, 'SECTION') + g(2, 'HEADER') + g(9, '$ACADVER') + g(1, 'AC1009') + g(9, '$INSUNITS') + g(70, 4) + g(0, 'ENDSEC') +
    g(0, 'SECTION') + g(2, 'TABLES') + g(0, 'TABLE') + g(2, 'LTYPE') + g(70, 2) + g(0, 'LTYPE') + g(2, 'CONTINUOUS') + g(70, 0) + g(3, 'Solid line') + g(72, 65) + g(73, 0) + g(40, 0) +
    g(0, 'LTYPE') + g(2, 'HIDDEN') + g(70, 0) + g(3, 'Hidden') + g(72, 65) + g(73, 2) + g(40, 6) + g(49, 4) + g(49, -2) + g(0, 'ENDTAB') +
    g(0, 'TABLE') + g(2, 'LAYER') + g(70, 3) + lay('0', 7, 'CONTINUOUS') + lay('UP', 3, 'HIDDEN') + lay('DOWN', 1, 'HIDDEN') + g(0, 'ENDTAB') + g(0, 'ENDSEC') +
    g(0, 'SECTION') + g(2, 'ENTITIES') + e.join('') + g(0, 'ENDSEC') + g(0, 'EOF');
  return {blob: new Blob([dxf], {type: 'application/dxf'}), w: pat.w, h: pat.h, t: best.t, holes: pat.loops.length - 1, bends: pat.bends.length, pat};
}

// SVG preview of a flat pattern (same colours as the DXF layers: black cut, blue bend up, magenta bend down)
export function patternSvg(pat) {
  const W = pat.w, H = pat.h, pad = Math.max(W, H) * 0.04, vw = W + 2 * pad, vh = H + 2 * pad, sw = Math.max(W, H) / 400;
  const X = x => (x + pad).toFixed(3), Y = y => (H - y + pad).toFixed(3);
  let b = '';
  for (const l of pat.loops) {
    const c = asCircle(l.pts);
    if (c) b += `<circle cx="${X(c.cx)}" cy="${Y(c.cy)}" r="${c.r.toFixed(3)}" fill="none" stroke="#111" stroke-width="${sw * 1.4}"/>`;
    else b += `<polygon points="${l.pts.map(p => X(p[0]) + ',' + Y(p[1])).join(' ')}" fill="rgba(80,120,200,.08)" stroke="#111" stroke-width="${sw * 1.4}" stroke-linejoin="round"/>`;
  }
  for (const k of pat.bends) b += `<line x1="${X(k.a[0])}" y1="${Y(k.a[1])}" x2="${X(k.b[0])}" y2="${Y(k.b[1])}" stroke="${k.up ? '#1f5fd6' : '#c2188a'}" stroke-width="${sw}" stroke-dasharray="${sw * 6} ${sw * 2.5} ${sw * 1.5} ${sw * 2.5}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${vw.toFixed(3)} ${vh.toFixed(3)}" style="width:100%;height:100%">${b}</svg>`;
}
