// Sheet-metal drawings PDF (A3 landscape): summary, folded views with dimensions, flat pattern with bend + hole tables.
import * as THREE from 'three';
import {buildModel} from './export-pdf.js';
import {makePattern, asCircle, area2} from './dxf-export.js';
import {buildView, trisOf, polyInside} from './solid-drawing.js';

const PW = 420, PH = 297, B = 10;                 // A3 landscape, border inset
const clean = s => String(s ?? '').replace(/[^\x20-\xFF]/g, '?');
const f1 = v => (Math.round(v * 10) / 10).toFixed(1);
const SCALES = [[10, '10:1'], [5, '5:1'], [2, '2:1'], [1, '1:1'], [1 / 2, '1:2'], [1 / 5, '1:5'], [1 / 10, '1:10'], [1 / 20, '1:20'], [1 / 25, '1:25'], [1 / 50, '1:50'], [1 / 100, '1:100'], [1 / 200, '1:200']];
const COL_UP = [0, 110, 200], COL_DOWN = [200, 0, 150], RED = [200, 30, 30];

// ---------- raster views of the folded part ----------
let R = null;
function getR() {
  if (R) return R;
  const renderer = new THREE.WebGLRenderer({antialias: true, preserveDrawingBuffer: true});
  renderer.setPixelRatio(1); renderer.setClearColor(0xffffff, 1);
  const scene = new THREE.Scene(), group = new THREE.Group(); scene.add(group);
  scene.add(new THREE.AmbientLight(0xffffff, 0.75));
  const dl = new THREE.DirectionalLight(0xffffff, 1.1); dl.position.set(-1, -2, 3); scene.add(dl);
  R = {renderer, scene, group, cam: new THREE.OrthographicCamera(-1, 1, 1, -1, -1e6, 1e6)};
  return R;
}
// dir: where the camera sits (looking at the part). wMm/hMm: frame size in mm of the drawing area.
function view(geom, box, dir, up, wMm, hMm, ppm, iso) {
  const {renderer, scene, group, cam} = getR();
  const wpx = Math.max(40, Math.round(wMm * ppm)), hpx = Math.max(40, Math.round(hMm * ppm));
  renderer.setSize(wpx, hpx, false);
  const mat = iso ? new THREE.MeshStandardMaterial({color: 0x8a9fb8, metalness: 0.1, roughness: 0.7, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1})
                  : new THREE.MeshBasicMaterial({color: 0xeef2f6, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1});
  const m = new THREE.Mesh(geom, mat);
  const e = new THREE.LineSegments((geom.userData && geom.userData.edgeGeo) || new THREE.EdgesGeometry(geom, 28), new THREE.LineBasicMaterial({color: 0x111111}));
  group.add(m, e);
  const c = box.getCenter(new THREE.Vector3());
  cam.up.set(...up); cam.position.copy(c).addScaledVector(new THREE.Vector3(...dir).normalize(), 1e4); cam.lookAt(c);
  cam.left = -wMm / 2; cam.right = wMm / 2; cam.top = hMm / 2; cam.bottom = -hMm / 2; cam.updateProjectionMatrix(); cam.updateMatrixWorld(true);
  renderer.render(scene, cam);
  const url = renderer.domElement.toDataURL('image/jpeg', 0.9);
  group.remove(m, e); e.geometry.dispose(); mat.dispose();
  return url;
}

// ---------- drawing helpers ----------
function frame(doc) {
  doc.setDrawColor(0); doc.setLineWidth(0.5); doc.rect(B, B, PW - 2 * B, PH - 2 * B);
  doc.setLineWidth(0.25); doc.setFontSize(8); doc.setFont('helvetica', 'normal'); doc.setTextColor(0);
  const cols = ['4', '3', '2', '1'], rows = ['D', 'C', 'B', 'A'], cw = (PW - 2 * B) / 4, rh = (PH - 2 * B) / 4;
  cols.forEach((c, i) => { const x = B + cw * (i + 0.5); doc.text(c, x, B - 3, {align: 'center'}); doc.text(c, x, PH - B + 6, {align: 'center'}); if (i) { const xx = B + cw * i; doc.line(xx, B, xx, B + 4); doc.line(xx, PH - B, xx, PH - B - 4); } });
  rows.forEach((r, i) => { const y = B + rh * (i + 0.5) + 1; doc.text(r, B - 5, y, {align: 'center'}); doc.text(r, PW - B + 5, y, {align: 'center'}); if (i) { const yy = B + rh * i; doc.line(B, yy, B + 4, yy); doc.line(PW - B, yy, PW - B - 4, yy); } });
}
const TB = {x: 252, w: 158};
function titleBlock(doc, o) {
  const x = TB.x, w = TB.w, y0 = 247, h = 38;
  doc.setDrawColor(0); doc.setLineWidth(0.3);
  doc.rect(x, y0 - 47, w, 44);                                     // notes box
  doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(0); doc.text('NOTES', x + 3, y0 - 42);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5);
  o.notes.forEach((n, i) => doc.text(clean(n), x + 3, y0 - 36 + i * 5.2));
  doc.rect(x, y0, w, h);
  doc.line(x, y0 + 14, x + w, y0 + 14); doc.line(x, y0 + 26, x + w, y0 + 26);
  doc.line(x + 52, y0 + 14, x + 52, y0 + 26); doc.line(x + 105, y0 + 14, x + 105, y0 + 26);
  doc.line(x + 22, y0 + 26, x + 22, y0 + h); doc.line(x + 70, y0 + 26, x + 70, y0 + h); doc.line(x + 110, y0 + 26, x + 110, y0 + h);
  const lab = (t, xx, yy) => { doc.setFontSize(5); doc.setTextColor(110); doc.text(t, xx + 1.5, yy + 3); doc.setTextColor(0); };
  lab('TITLE', x, y0); lab('DWG NO.', x, y0 + 14); lab('MATERIAL', x + 52, y0 + 14); lab(o.tkLabel || 'THICKNESS / K-FACTOR', x + 105, y0 + 14);
  lab('SCALE', x, y0 + 26); lab('SHEET', x + 22, y0 + 26); lab('PROJECTION', x + 70, y0 + 26); lab('UNITS / DATE', x + 110, y0 + 26);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text(clean(o.title), x + w / 2, y0 + 10, {align: 'center'});
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
  doc.text(clean(o.dwg), x + 26, y0 + 22, {align: 'center'}); doc.text(o.mat || 'MILD STEEL', x + 78, y0 + 22, {align: 'center'}); doc.text(clean(o.tk), x + 131, y0 + 22, {align: 'center'});
  doc.text(clean(o.scale), x + 11, y0 + 34, {align: 'center'}); doc.text(`${o.sheet} of ${o.total}`, x + 46, y0 + 34, {align: 'center'});
  doc.text(o.proj || 'FIRST ANGLE', x + 90, y0 + 34, {align: 'center'}); doc.text(clean('mm  ' + o.date), x + 134, y0 + 34, {align: 'center'});
}
function arrow(doc, x, y, dx, dy) { // arrow head at (x,y) pointing along (dx,dy)
  const L = 2.2, W = 0.7, px = -dy, py = dx;
  doc.setFillColor(0); doc.triangle(x, y, x - dx * L + px * W, y - dy * L + py * W, x - dx * L - px * W, y - dy * L - py * W, 'F');
}
function dimH(doc, x1, x2, y, txt, off = 0) { // horizontal dimension; extension lines go from y+off... drawn at y
  doc.setLineWidth(0.18); doc.setDrawColor(0); doc.line(x1, y, x2, y);
  arrow(doc, x1, y, 1, 0); arrow(doc, x2, y, -1, 0);
  doc.setFontSize(7); doc.setFont('helvetica', 'normal'); doc.setTextColor(0); doc.text(txt, (x1 + x2) / 2, y - 1.3, {align: 'center'});
}
function dimV(doc, y1, y2, x, txt) {
  doc.setLineWidth(0.18); doc.setDrawColor(0); doc.line(x, y1, x, y2);
  arrow(doc, x, y1, 0, 1); arrow(doc, x, y2, 0, -1);
  doc.setFontSize(7); doc.setFont('helvetica', 'normal'); doc.setTextColor(0); doc.text(txt, x - 1.3, (y1 + y2) / 2, {angle: 90, align: 'center'});
}
const ext = (doc, x1, y1, x2, y2) => { doc.setLineWidth(0.12); doc.setDrawColor(60); doc.line(x1, y1, x2, y2); };
const pickScale = (fits) => { for (const s of SCALES) if (fits(s[0])) return s; return SCALES[SCALES.length - 1]; };

// ---------- main ----------
export async function buildDrawingsPdf(ctx, opts = {}, progress = () => {}) {
  const {jsPDF} = window.jspdf, K = opts.k ?? 0.33;
  const {lines} = buildModel(ctx);
  const sheet = lines.filter(L => L.t > 0);
  if (!sheet.length) throw new Error('No sheet-metal parts were found in this model.');
  const title = clean(opts.title || 'Assembly'), date = (() => { const d = new Date(); return String(d.getDate()).padStart(2, '0') + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + d.getFullYear(); })();
  const prefix = clean(opts.dwg || (title.split(/\s+/).map(w => w[0]).join('').toUpperCase().slice(0, 6) || 'DWG')).replace(/\s+/g, '');
  const doc = new jsPDF({unit: 'mm', format: 'a3', orientation: 'landscape'});
  const items = []; let solid = 0;
  let i = 0;
  for (const L of sheet) {
    progress(`Unfolding ${++i}/${sheet.length}: ${L.name}`, 0.4 * i / sheet.length);
    await new Promise(r => setTimeout(r, 0));
    const p = L.parts[0], geom = p.mesh.geometry;
    geom.computeBoundingBox();
    const box = geom.boundingBox.clone(), sz = box.getSize(new THREE.Vector3());
    const rec = {L, p, geom, box, sz, qty: L.parts.length};
    try { const r = makePattern(geom, L.t, K, !!opts.flip); if (r.solid) { solid++; continue; } rec.pat = r.pat; rec.t = r.t; } catch (e) { rec.err = e.message; rec.t = L.t; }
    items.push(rec);
  }
  const ok = items.filter(r => r.pat);
  if (!ok.length) throw new Error('No real sheet-metal parts found (solid or machined parts are left out).');
  // analyse flat patterns
  const tset = [...new Set(ok.map(r => r.t))];
  const tTxt = tset.length === 1 ? tset[0] + ' mm' : 'see table';
  ok.forEach((r, k) => {
    const pat = r.pat, outer = pat.loops.reduce((a, b) => Math.abs(area2(a.pts)) >= Math.abs(area2(b.pts)) ? a : b);
    r.holes = []; let net = Math.abs(area2(outer.pts));
    for (const l of pat.loops) if (l !== outer) {
      net -= Math.abs(area2(l.pts));
      const c = asCircle(l.pts);
      if (c) r.holes.push({d: 2 * c.r, x: c.cx, y: c.cy, circle: true});
      else { let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18; l.pts.forEach(v => { x0 = Math.min(x0, v[0]); x1 = Math.max(x1, v[0]); y0 = Math.min(y0, v[1]); y1 = Math.max(y1, v[1]); }); r.holes.push({w: x1 - x0, h: y1 - y0, x: (x0 + x1) / 2, y: (y0 + y1) / 2, circle: false}); }
    }
    r.holes.sort((a, b) => a.y - b.y || a.x - b.x);
    r.mass = net * r.t * 7.85e-6;
    r.bends = pat.bends.map(k2 => {
      const th = k2.deg * Math.PI / 180, ri = k2.ba > 0.05 ? Math.max(0, k2.ba / th - K * r.t) : r.t;
      const horiz = Math.abs(k2.b[0] - k2.a[0]) >= Math.abs(k2.b[1] - k2.a[1]);
      return {...k2, ri, ba: k2.ba > 0.05 ? k2.ba : th * (r.t + K * r.t), horiz, pos: horiz ? (k2.a[1] + k2.b[1]) / 2 : (k2.a[0] + k2.b[0]) / 2, len: Math.hypot(k2.b[0] - k2.a[0], k2.b[1] - k2.a[1])};
    }).sort((a, b) => (a.horiz === b.horiz ? a.pos - b.pos : a.horiz ? -1 : 1));
    r.no = k + 1; r.dwg = `${prefix}-P${r.L.no}`; r.s0 = 2 + 2 * k; r.name = clean(r.L.name).replace(/_/g, ' ');
  });
  const total = 1 + 2 * ok.length;
  const radii = [...new Set(ok.flatMap(r => r.bends.map(b => Math.round(b.ri * 2) / 2)))];

  // ---------------- page 1: summary ----------------
  doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(0);
  doc.text('Sheet-metal parts: drawings and flat patterns (all dimensions in mm)', 20, 25);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(90);
  doc.text(clean(`Source: ${ctx.file.name || title} | Sheet thickness ${tTxt} | K-factor ${K} | ${ok.length} sheet-metal part types`), 20, 32);
  const cx = [20, 85, 130, 158, 186, 236, 292, 330], hd = ['Part', 'Thickness', 'Flat L x W (mm)', 'Bends', 'Holes / cut-outs', 'Folded size X x Y x Z (mm)', 'Mass (steel) / qty', 'Sheets'];
  let y = 46; doc.setTextColor(0); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
  hd.forEach((h, k) => doc.text(h, cx[k], y)); doc.setLineWidth(0.3); doc.line(20, y + 2, 400, y + 2);
  doc.setFont('helvetica', 'normal'); y += 9;
  for (const r of items) {
    if (y > 270) { doc.addPage(); frame(doc); y = 30; }
    const row = r.pat ? [r.name.slice(0, 34), r.t + ' mm', `${f1(r.pat.w)} x ${f1(r.pat.h)}`, String(r.pat.bends.length), String(r.holes.length), `${Math.round(r.sz.x)} x ${Math.round(r.sz.y)} x ${Math.round(r.sz.z)}`, `${r.mass.toFixed(2)} kg x ${r.qty}`, `${r.s0}-${r.s0 + 1}`]
      : [r.name.slice(0, 34), '', 'could not unfold', '', '', '', '', ''];
    row.forEach((t, k) => doc.text(clean(t), cx[k], y)); y += 8;
  }
  y += 6; doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('Notes', 20, y); doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); y += 6;
  [`Each part has two sheets: (1) folded views with dimensions (front, left, top, isometric), (2) flat pattern with bend lines.`,
   `Solid lines = cut contour (outline, holes, slots). Dashed coloured lines = bend lines (do not cut): blue = bend UP (toward you), magenta = bend DOWN (away from you).`,
   `Bend positions are measured from the left edge / bottom edge of the flat blank to the bend centre line.`,
   `Hole table lists the centre (X, Y) of every hole or cut-out, measured from the lower-left corner of the flat blank.`,
   `Bend allowance from K = ${K} (BA = angle x (r + K x t)). Inner radius is measured from the model${radii.length ? ' (about ' + radii.join(', ') + ' mm)' : ''}. Verify against your press-brake data before cutting.`,
   `Flat patterns are calculated from the 3D model; hole and slot sizes are read from the geometry (+/-0.1 mm). Thickness is estimated from the model.`,
   `Part names come from the file. Material is assumed to be mild steel (7.85 g/cm3).`,
   ...(solid ? [`${solid} solid / machined part type(s) were left out because they are not sheet metal.`] : [])].forEach(t => { doc.text(clean(t), 20, y); y += 5.5; });
  frame(doc);

  // ---------------- per part ----------------
  for (let k = 0; k < ok.length; k++) {
    const r = ok[k], pat = r.pat;
    progress(`Drawing ${k + 1}/${ok.length}: ${r.name}`, 0.4 + 0.6 * k / ok.length);
    await new Promise(q => setTimeout(q, 0));
    const common = {title: r.name.toUpperCase().slice(0, 34), dwg: r.dwg, tk: `${r.t} mm / ${K}`, total, date};
    // ----- sheet A: folded views -----
    doc.addPage(); frame(doc);
    const X = r.sz.x, Y = r.sz.y, Z = r.sz.z, gap = 34;
    const sc = pickScale(s => X * s <= 190 && (Z + Y) * s + gap <= 170 && Y * s <= 130 && Z * s <= 80);
    const s = sc[0];
    const ppm = Math.min(14, 1400 / Math.max(X * s, Y * s, Z * s, 1));
    const fx = 28, fy = 38, fw = X * s, fh = Z * s, ty = fy + fh + gap, th = Y * s, lx = 268, lw = Y * s;
    const pad = 3 / ppm;
    const put = (url, x, yy, w, h) => doc.addImage(url, 'JPEG', x - pad, yy - pad, w + 2 * pad, h + 2 * pad);
    put(view(r.geom, r.box, [0, -1, 0], [0, 0, 1], X + 2 * pad / s, Z + 2 * pad / s, ppm * s, false), fx, fy, fw, fh);
    put(view(r.geom, r.box, [0, 0, 1], [0, 1, 0], X + 2 * pad / s, Y + 2 * pad / s, ppm * s, false), fx, ty, fw, th);
    put(view(r.geom, r.box, [-1, 0, 0], [0, 0, 1], Y + 2 * pad / s, Z + 2 * pad / s, ppm * s, false), lx, fy, lw, fh);
    // iso (not to scale), fitted in a box
    const bx = 262, by = Math.max(100, fy + fh + 22), bw = 140, bh = Math.max(40, Math.min(88, 184 - by)), d = Math.hypot(X, Y, Z), isoS = Math.min(bw, bh) / d * 0.92;
    {
      const w = bw / isoS, h = bh / isoS;
      doc.addImage(view(r.geom, r.box, [1, -1.25, 0.9], [0, 0, 1], w, h, Math.min(14, 1400 / Math.max(w, h)), true), 'JPEG', bx, by, bw, bh);
    }
    // dimensions
    doc.setDrawColor(0);
    ext(doc, fx, fy, fx, fy - 9); ext(doc, fx + fw, fy, fx + fw, fy - 9); dimH(doc, fx, fx + fw, fy - 7, f1(X).replace(/\.0$/, '.0'));
    ext(doc, fx, fy, fx - 8, fy); ext(doc, fx, fy + fh, fx - 8, fy + fh); dimV(doc, fy, fy + fh, fx - 6, f1(Z));
    ext(doc, fx, ty + th, fx, ty + th + 8); ext(doc, fx + fw, ty + th, fx + fw, ty + th + 8); dimH(doc, fx, fx + fw, ty + th + 6, f1(X));
    ext(doc, fx, ty, fx - 8, ty); ext(doc, fx, ty + th, fx - 8, ty + th); dimV(doc, ty, ty + th, fx - 6, f1(Y));
    ext(doc, lx, fy, lx, fy - 9); ext(doc, lx + lw, fy, lx + lw, fy - 9); dimH(doc, lx, lx + lw, fy - 7, f1(Y));
    ext(doc, lx, fy, lx - 8, fy); ext(doc, lx, fy + fh, lx - 8, fy + fh); dimV(doc, fy, fy + fh, lx - 6, f1(Z));
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(0);
    const lab = (t, sub, x, yy) => { doc.text(t, x, yy, {align: 'center'}); doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.text(sub, x, yy + 4.5, {align: 'center'}); doc.setFont('helvetica', 'bold'); doc.setFontSize(9); };
    lab('FRONT VIEW', `( ${sc[1]} )`, fx + fw / 2, fy + fh + 9);
    lab('TOP VIEW', `( ${sc[1]} )`, fx + fw / 2, ty + th + 16);
    lab('LEFT VIEW', `( ${sc[1]} )`, lx + lw / 2, fy + fh + 9);
    lab('ISOMETRIC VIEW', '( NOT TO SCALE )', bx + bw / 2, by + bh + 6);
    // hole summary
    const groups = new Map(); r.holes.filter(h => h.circle).forEach(h => { const key = h.d.toFixed(1); groups.set(key, (groups.get(key) || 0) + 1); });
    const hs = [...groups.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([dd, n]) => `${n} x Ø${dd}`).join(', ');
    const cut = r.holes.filter(h => !h.circle).length;
    titleBlock(doc, {...common, sheet: r.s0, scale: sc[1], notes: [
      '1. ALL DIMENSIONS ARE IN MILLIMETERS.', `2. MATERIAL THICKNESS = ${r.t} mm.`,
      `3. K-FACTOR ${K}, INNER BEND RADIUS ABOUT ${[...new Set(r.bends.map(b => Math.round(b.ri * 2) / 2))].join(' / ') || '-'} mm.`,
      `4. HOLES: ${hs || 'none'}${cut ? `, ${cut} CUT-OUT(S)` : ''}.`, '5. FLAT PATTERN WITH BEND LINES ON NEXT SHEET.']});

    // ----- sheet B: flat pattern -----
    doc.addPage(); frame(doc);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(0); doc.text(`${clean(r.L.name)} - flat pattern`, 20, 24);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(90);
    doc.text('Solid = cut. Dashed blue = bend UP, dashed magenta = bend DOWN (do not cut). Red numbers = hole table reference.', 20, 30);
    const W = pat.w, H = pat.h;
    const fs = pickScale(q => W * q <= 190 && H * q <= 175);
    const q = fs[0], ox = 40, oy = 45 + (175 - H * q) / 2 + 12, Hq = H * q;
    const X0 = x => ox + x * q, Y0 = yy => oy + (H - yy) * q;
    doc.setDrawColor(0); doc.setLineWidth(0.35);
    for (const l of pat.loops) {
      const c = asCircle(l.pts);
      if (c) doc.circle(X0(c.cx), Y0(c.cy), Math.max(c.r * q, 0.25), 'S');
      else { const p0 = l.pts[0]; doc.lines(l.pts.slice(1).concat([l.pts[0]]).map((v, ii) => [(v[0] - (ii ? l.pts[ii][0] : p0[0])) * q, -(v[1] - (ii ? l.pts[ii][1] : p0[1])) * q]), X0(p0[0]), Y0(p0[1]), [1, 1], 'S', true); }
    }
    doc.setLineWidth(0.25);
    for (const b of r.bends) { doc.setDrawColor(...(b.up ? COL_UP : COL_DOWN)); doc.setLineDashPattern([3, 1, 0.6, 1], 0); doc.line(X0(b.a[0]), Y0(b.a[1]), X0(b.b[0]), Y0(b.b[1])); }
    doc.setLineDashPattern([], 0); doc.setDrawColor(0);
    doc.setFontSize(5.5); doc.setTextColor(...RED);
    r.holes.forEach((h, ii) => doc.text(String(ii + 1), X0(h.x) + 1.4, Y0(h.y) - 1.2));
    doc.setTextColor(0);
    // overall dimensions
    ext(doc, X0(0), Y0(0), X0(0), Y0(0) + 10); ext(doc, X0(W), Y0(0), X0(W), Y0(0) + 10); dimH(doc, X0(0), X0(W), Y0(0) + 8, f1(W));
    ext(doc, X0(0), Y0(H), X0(0) - 10, Y0(H)); ext(doc, X0(0), Y0(0), X0(0) - 10, Y0(0)); dimV(doc, Y0(H), Y0(0), X0(0) - 8, f1(H));
    const hb = r.bends.filter(b => b.horiz), vb = r.bends.filter(b => !b.horiz);
    if (hb.length) {
      const ys = [0, ...hb.map(b => b.pos), H];
      for (const v of ys) ext(doc, X0(W), Y0(v), X0(W) + 12, Y0(v));
      for (let j = 0; j < ys.length - 1; j++) dimV(doc, Y0(ys[j + 1]), Y0(ys[j]), X0(W) + 9, f1(ys[j + 1] - ys[j]));
    }
    if (vb.length) {
      const xs = [0, ...vb.map(b => b.pos), W];
      for (const v of xs) ext(doc, X0(v), Y0(H), X0(v), Y0(H) - 12);
      for (let j = 0; j < xs.length - 1; j++) dimH(doc, X0(xs[j]), X0(xs[j + 1]), Y0(H) - 9, f1(xs[j + 1] - xs[j]));
    }
    // hole positions: ordinate dimensions (X from the left edge along the top, Y from the bottom edge along the right side)
    if (r.holes.length) {
      const uniq = (arr) => { const o = []; for (const v of arr.sort((a, b) => a - b)) if (!o.length || v - o[o.length - 1] > 0.25) o.push(v); return o.slice(0, 16); };
      const xs = uniq(r.holes.map(h => h.x)), ys = uniq(r.holes.map(h => h.y));
      const yTop = Y0(H) - (vb.length ? 20 : 8), xRt = X0(W) + (hb.length ? 22 : 10);
      doc.setDrawColor(0); doc.setLineWidth(0.12); doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5); doc.setTextColor(0);
      doc.setLineDashPattern([6, 1.2, 1.2, 1.2], 0);
      r.holes.forEach(h => { const cx = X0(h.x), cy = Y0(h.y), rr = (h.circle ? h.d / 2 : Math.max(h.w, h.h) / 2) * q + 2; doc.line(cx - rr, cy, cx + rr, cy); doc.line(cx, cy - rr, cx, cy + rr); });
      doc.setLineDashPattern([], 0);
      xs.forEach((v, i) => { const x = X0(v), yt = yTop - (i % 2) * 0; const hs = r.holes.filter(h => Math.abs(h.x - v) <= 0.25), ytop = Math.min(...hs.map(h => Y0(h.y)));
        doc.line(x, ytop - 2, x, yt - 1.5); doc.text(f1(v), x, yt - 2.5, {align: 'center', angle: 0}); });
      doc.line(X0(0), yTop, X0(W), yTop);
      ys.forEach((v) => { const y = Y0(v), hs = r.holes.filter(h => Math.abs(h.y - v) <= 0.25), xr = Math.max(...hs.map(h => X0(h.x)));
        doc.line(xr + 2, y, xRt + 1.5, y); doc.text(f1(v), xRt + 2.5, y + 0.9); });
      doc.line(xRt, Y0(H), xRt, Y0(0));
      doc.setFontSize(5.5); doc.setTextColor(90); doc.text('X from left edge', X0(0), yTop - 6); doc.text('Y from bottom', xRt - 4, Y0(H) - 4); doc.setTextColor(0);
    }
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.text(`Scale ${fs[1]}`, X0(W / 2), Y0(0) + 18, {align: 'center'});
    // tables
    const tx = 262; let ty2 = 24;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.text('Holes / cut-outs (centre X, Y from lower-left corner, mm)', tx, ty2); ty2 += 5;
    doc.setFont('courier', 'normal'); doc.setFontSize(6.2);
    const per = Math.max(1, Math.floor((195 - 24) / 3.4)), cols = Math.max(1, Math.ceil(r.holes.length / per));
    doc.setFont('courier', 'bold'); for (let c = 0; c < Math.min(cols, 2); c++) doc.text('No Feature        X       Y', tx + c * 76, ty2); doc.setFont('courier', 'normal');
    r.holes.slice(0, per * 2).forEach((h, ii) => {
      const c = Math.floor(ii / per), row = ii % per;
      const feat = h.circle ? 'Ø' + h.d.toFixed(2) : `${f1(h.w)}x${f1(h.h)}`;
      doc.text(`${String(ii + 1).padStart(2)} ${feat.padEnd(10)} ${h.x.toFixed(1).padStart(7)} ${h.y.toFixed(1).padStart(7)}`, tx + c * 76, ty2 + 4 + row * 3.4);
    });
    const used = 4 + Math.min(per, r.holes.length) * 3.4;
    let by2 = ty2 + used + 10;
    if (r.holes.length > per * 2) { doc.setFontSize(6); doc.text(`(${r.holes.length - per * 2} more not shown)`, tx, by2 - 6); }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.text('Bends (position of bend centre line from left / bottom edge)', tx, by2); by2 += 5;
    doc.setFont('courier', 'normal'); doc.setFontSize(6.5);
    r.bends.forEach((b, ii) => {
      if (by2 > 196) return;
      doc.setTextColor(...(b.up ? COL_UP : COL_DOWN));
      const ang = Math.abs(b.deg - Math.round(b.deg)) < 0.4 ? String(Math.round(b.deg)) : b.deg.toFixed(1);
      doc.text(`B${ii + 1} ${b.horiz ? 'Y' : 'X'}=${b.pos.toFixed(1).padEnd(7)} ${(b.up ? 'UP  ' : 'DOWN')} ${ang} deg R${b.ri.toFixed(1)} BA ${b.ba.toFixed(2)} len ${b.len.toFixed(1)}`, tx, by2);
      by2 += 3.8;
    });
    doc.setTextColor(0);
    titleBlock(doc, {...common, title: common.title + ' (FLAT)', sheet: r.s0 + 1, scale: fs[1], notes: [
      `FLAT BLANK ${f1(W)} x ${f1(H)} mm, ${r.bends.length} BENDS, ${r.holes.length} HOLES/CUT-OUTS.`,
      `MASS (STEEL) ${r.mass.toFixed(2)} kg PER PIECE, QTY ${r.qty}.`,
      `BEND ALLOWANCE FROM K = ${K}, VERIFY WITH PRESS-BRAKE DATA.`, 'ORIGIN = LOWER-LEFT CORNER OF THE FLAT BLANK.']});
  }
  doc.setProperties({title: `${title} - sheet-metal drawings`});
  return {blob: doc.output('blob'), pages: total, parts: ok.length, failed: items.length - ok.length, solid};
}


// ======================= solid / machined parts =======================
function circlesOf(geom, box) {
  const eg = new THREE.EdgesGeometry(geom, 28), pa = eg.attributes.position, n = pa.count / 2;
  if (n > 250000) { eg.dispose(); return []; }
  const map = new Map(), V = [], key = (x, y, z) => Math.round(x / 0.01) + ',' + Math.round(y / 0.01) + ',' + Math.round(z / 0.01);
  const vid = i => { const x = pa.getX(i), y = pa.getY(i), z = pa.getZ(i), k = key(x, y, z); let id = map.get(k); if (id === undefined) { id = V.length; V.push([x, y, z]); map.set(k, id); } return id; };
  const E = [], adj = new Map();
  for (let i = 0; i < n; i++) { const a = vid(2 * i), b = vid(2 * i + 1); if (a === b) continue; E.push([a, b]); (adj.get(a) || adj.set(a, []).get(a)).push(E.length - 1); (adj.get(b) || adj.set(b, []).get(b)).push(E.length - 1); }
  eg.dispose();
  const used = new Uint8Array(E.length), feats = new Map();
  for (let e0 = 0; e0 < E.length; e0++) {
    if (used[e0]) continue;
    const loop = [E[e0][0]]; let cur = E[e0][1], e = e0, closed = false; used[e0] = 1;
    for (let g = 0; g < 100000; g++) {
      if (cur === loop[0]) { closed = true; break; }
      loop.push(cur);
      const nx = adj.get(cur); if (nx.length !== 2) break;
      const ne = nx[0] === e ? nx[1] : nx[0]; if (used[ne]) break;
      used[ne] = 1; cur = E[ne][0] === cur ? E[ne][1] : E[ne][0]; e = ne;
    }
    if (!closed || loop.length < 8) continue;
    const P = loop.map(i => V[i]); const c = [0, 0, 0]; P.forEach(p => { c[0] += p[0]; c[1] += p[1]; c[2] += p[2]; }); c[0] /= P.length; c[1] /= P.length; c[2] /= P.length;
    let nx = 0, ny = 0, nz = 0;                                        // Newell normal
    for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; nx += (a[1] - b[1]) * (a[2] + b[2]); ny += (a[2] - b[2]) * (a[0] + b[0]); nz += (a[0] - b[0]) * (a[1] + b[1]); }
    const nl = Math.hypot(nx, ny, nz); if (nl < 1e-9) continue;
    let nn = [nx / nl, ny / nl, nz / nl];
    const rs = P.map(p => Math.hypot(p[0] - c[0], p[1] - c[1], p[2] - c[2])), r = rs.reduce((a, b) => a + b, 0) / rs.length;
    if (r < 0.3 || Math.max(...rs.map(v => Math.abs(v - r))) > 0.03 * r + 0.03) continue;
    if (Math.max(...P.map(p => Math.abs((p[0] - c[0]) * nn[0] + (p[1] - c[1]) * nn[1] + (p[2] - c[2]) * nn[2]))) > 0.03 * r + 0.03) continue;
    const big = [0, 1, 2].reduce((a, b) => Math.abs(nn[b]) > Math.abs(nn[a]) ? b : a, 0); if (nn[big] < 0) nn = nn.map(v => -v);
    const ax = nn.map(v => Math.abs(v) > 0.999 ? Math.sign(v) : Math.round(v * 1000) / 1000);
    const along = c[0] * nn[0] + c[1] * nn[1] + c[2] * nn[2], cp = [c[0] - along * nn[0], c[1] - along * nn[1], c[2] - along * nn[2]];
    const k = ax.join(',') + '|' + cp.map(v => Math.round(v / 0.05)).join(',') + '|' + Math.round(r / 0.02);
    const f = feats.get(k) || {r, c: cp.slice(), nn, aligned: Math.abs(nn[big]) > 0.999 ? 'xyz'[big] : null, lo: Infinity, hi: -Infinity};
    f.lo = Math.min(f.lo, along); f.hi = Math.max(f.hi, along); feats.set(k, f);
  }
  const out = [...feats.values()].map(f => {
    const mid = (f.lo + f.hi) / 2, c = [f.c[0] + mid * f.nn[0], f.c[1] + mid * f.nn[1], f.c[2] + mid * f.nn[2]];
    return {d: 2 * f.r, c: [c[0] - box.min.x, c[1] - box.min.y, c[2] - box.min.z], axis: f.aligned, len: f.hi - f.lo, nn: f.nn};
  });
  out.sort((a, b) => b.d - a.d || a.c[0] - b.c[0] || a.c[1] - b.c[1] || a.c[2] - b.c[2]);
  return out;
}
function volumeOf(g) {
  const p = g.attributes.position, ix = g.index, cnt = ix ? ix.count : p.count; let v = 0;
  for (let i = 0; i < cnt; i += 3) {
    const a = ix ? ix.getX(i) : i, b = ix ? ix.getX(i + 1) : i + 1, c = ix ? ix.getX(i + 2) : i + 2;
    const ax = p.getX(a), ay = p.getY(a), az = p.getZ(a), bx = p.getX(b), by = p.getY(b), bz = p.getZ(b), cx = p.getX(c), cy = p.getY(c), cz = p.getZ(c);
    v += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
  }
  return Math.abs(v);
}

export async function buildSolidDrawingsPdf(ctx, opts = {}, progress = () => {}) {
  const {jsPDF} = window.jspdf;
  const {lines} = buildModel(ctx);
  const title = clean(opts.title || 'Assembly'), date = (() => { const d = new Date(); return String(d.getDate()).padStart(2, '0') + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + d.getFullYear(); })();
  const prefix = clean(opts.dwg || (title.split(/\s+/).map(w => w[0]).join('').toUpperCase().slice(0, 6) || 'DWG')).replace(/\s+/g, '');
  const items = []; let i = 0, sheetCount = 0;
  for (const L of lines) {
    progress(`Checking ${++i}/${lines.length}: ${L.name}`, 0.3 * i / lines.length);
    if (i % 4 === 0) await new Promise(r => setTimeout(r, 0));
    const geom = L.parts[0].mesh.geometry;
    if (L.t > 0) { try { const r = makePattern(geom, L.t, opts.k ?? 0.33, false); if (!r.solid) { sheetCount++; continue; } } catch (e) { /* treat as solid */ } }
    items.push({L, geom});
  }
  if (!items.length) throw new Error('No solid parts found: every part in this model is sheet metal.');
  items.forEach((r, k) => {
    r.geom.computeBoundingBox(); r.box = r.geom.boundingBox.clone(); r.sz = r.box.getSize(new THREE.Vector3());
    r.no = k + 1; r.name = clean(r.L.name).replace(/_/g, ' '); r.qty = r.L.parts.length; r.dwg = `${prefix}-S${r.L.no}`;
    r.vol = volumeOf(r.geom);
    r.feats = circlesOf(r.geom, r.box);
    r.s0 = 2 + k * 0; // set below
  });
  let sh = 2; items.forEach(r => { r.s0 = sh; sh += r.feats.length ? 2 : 1; });
  const total = sh - 1;
  const doc = new jsPDF({unit: 'mm', format: 'a3', orientation: 'landscape'});
  // ---- summary ----
  doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(0);
  doc.text('Solid / machined parts: dimensioned drawings (all dimensions in mm)', 20, 25);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(90);
  doc.text(clean(`Source: ${ctx.file.name || title} | ${items.length} solid part types${sheetCount ? ` (${sheetCount} sheet-metal part types are in the sheet-metal drawings instead)` : ''}`), 20, 32);
  const cx = [20, 100, 175, 225, 262, 300], hd = ['Part', 'Overall X x Y x Z (mm)', 'Volume (cm3)', 'Qty', 'Holes / shafts', 'Sheets'];
  let y = 46; doc.setTextColor(0); doc.setFont('helvetica', 'bold'); doc.setFontSize(9); hd.forEach((h, k) => doc.text(h, cx[k], y)); doc.setLineWidth(0.3); doc.line(20, y + 2, 400, y + 2);
  doc.setFont('helvetica', 'normal'); y += 9;
  for (const r of items) {
    if (y > 272) { doc.addPage(); frame(doc); y = 30; }
    [r.name.slice(0, 40), `${f1(r.sz.x)} x ${f1(r.sz.y)} x ${f1(r.sz.z)}`, (r.vol / 1000).toFixed(2), String(r.qty), String(r.feats.length), r.feats.length ? `${r.s0}-${r.s0 + 1}` : String(r.s0)].forEach((t, k) => doc.text(clean(t), cx[k], y)); y += 7.5;
  }
  frame(doc);
  const common = {mat: 'AS PER MODEL', tkLabel: 'VOLUME', total, date};
  for (let k = 0; k < items.length; k++) {
    const r = items[k];
    progress(`Drawing ${k + 1}/${items.length}: ${r.name}`, 0.3 + 0.7 * k / items.length);
    await new Promise(q => setTimeout(q, 0));
    drawSolidSheet(doc, r, {...common, title: r.name.toUpperCase().slice(0, 34), dwg: r.dwg, tk: `${(r.vol / 1000).toFixed(2)} cm3`, sheet: r.s0});
    // ---- feature table sheet ----
    if (r.feats.length) {
      doc.addPage(); frame(doc);
      doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(0); doc.text(`${clean(r.L.name)} - holes and shafts`, 20, 24);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(90);
      doc.text('Diameter, centre position from the lower-front-left corner of the part (X right, Y back, Z up) and length along the axis. Red numbers on the views refer to this table.', 20, 30);
      doc.setTextColor(0); doc.setFont('courier', 'bold'); doc.setFontSize(7);
      const per = 62, hdr = 'No  Dia     Axis      X       Y       Z     Length';
      for (let c = 0; c < 2; c++) doc.text(hdr, 20 + c * 115, 40);
      doc.setFont('courier', 'normal');
      r.feats.slice(0, per * 2).forEach((f, ii) => {
        const c = Math.floor(ii / per), row = ii % per, ax = f.axis ? f.axis.toUpperCase() : 'tilted';
        doc.text(`${String(ii + 1).padStart(2)} \u00D8${f.d.toFixed(2).padStart(6)}  ${ax.padEnd(6)} ${f.c[0].toFixed(1).padStart(7)} ${f.c[1].toFixed(1).padStart(7)} ${f.c[2].toFixed(1).padStart(7)} ${(f.len > 0.05 ? f.len.toFixed(1) : '-').padStart(7)}`, 20 + c * 115, 45 + row * 3.9);
      });
      if (r.feats.length > per * 2) { doc.setFontSize(7); doc.text(`(${r.feats.length - per * 2} more features not shown)`, 20, 45 + per * 3.9 + 4); }
      const cm = {title: r.name.toUpperCase().slice(0, 34), dwg: r.dwg, tk: `${(r.vol / 1000).toFixed(2)} cm3`, ...common};
      titleBlock(doc, {...cm, proj: 'FIRST ANGLE', title: cm.title + ' (FEATURES)', sheet: r.s0 + 1, scale: '-', notes: [`${r.feats.length} HOLE / SHAFT FEATURES FOUND.`, 'AXIS X / Y / Z = ALIGNED WITH THAT DIRECTION.', 'POSITION = FEATURE CENTRE, MID-LENGTH.', 'ONLY FULL CIRCLES ARE LISTED (ARCS AND SLOTS ARE NOT).']});
    }
  }
  doc.setProperties({title: `${title} - solid parts drawings`});
  return {blob: doc.output('blob'), pages: total, parts: items.length, sheetParts: sheetCount};
}


// ---------- engineering drawing of one solid part (third angle, like a drawing-practice sheet) ----------
const fmtN = v => (Math.abs(v - Math.round(v)) < 0.05 ? String(Math.round(v)) : v.toFixed(1));
const pg = (T, a, b) => [T.ox + (a - T.a0) * T.s, T.oy + (T.b1 - b) * T.s];
function dHor(doc, x1, y1, x2, y2, yd, txt) {
  const sg = yd > Math.max(y1, y2) ? 1 : -1, small = Math.abs(x2 - x1) < 8;
  doc.setLineWidth(0.12); doc.setDrawColor(60);
  doc.line(x1, y1 + sg * 1.2, x1, yd + sg * 1.5); doc.line(x2, y2 + sg * 1.2, x2, yd + sg * 1.5);
  doc.setLineWidth(0.18); doc.setDrawColor(0);
  const lo = Math.min(x1, x2), hi = Math.max(x1, x2);
  if (small) { doc.line(lo - 4, yd, hi + 4, yd); arrow(doc, lo, yd, 1, 0); arrow(doc, hi, yd, -1, 0); } else { doc.line(lo, yd, hi, yd); arrow(doc, lo, yd, 1, 0); arrow(doc, hi, yd, -1, 0); }
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(0);
  if (small) doc.text(txt, hi + 5, yd + 1, {align: 'left'}); else doc.text(txt, (lo + hi) / 2, yd - 1.2, {align: 'center'});
}
function dVer(doc, x1, y1, x2, y2, xd, txt) {
  const sg = xd > Math.max(x1, x2) ? 1 : -1, small = Math.abs(y2 - y1) < 8;
  doc.setLineWidth(0.12); doc.setDrawColor(60);
  doc.line(x1 + sg * 1.2, y1, xd + sg * 1.5, y1); doc.line(x2 + sg * 1.2, y2, xd + sg * 1.5, y2);
  doc.setLineWidth(0.18); doc.setDrawColor(0);
  const lo = Math.min(y1, y2), hi = Math.max(y1, y2);
  if (small) { doc.line(xd, lo - 4, xd, hi + 4); arrow(doc, xd, lo, 0, 1); arrow(doc, xd, hi, 0, -1); } else { doc.line(xd, lo, xd, hi); arrow(doc, xd, lo, 0, 1); arrow(doc, xd, hi, 0, -1); }
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(0);
  if (small) doc.text(txt, xd - 1.2, hi + 5, {angle: 90, align: 'left'}); else doc.text(txt, xd - 1.2, (lo + hi) / 2, {angle: 90, align: 'center'});
}
function pickCoords(cands, lo, hi, maxN) {
  const out = [];
  for (const c of cands.sort((a, b) => b.w - a.w)) { if (c.v < lo + 0.3 || c.v > hi - 0.3) continue; if (out.some(o => Math.abs(o.v - c.v) < 0.25)) continue; out.push(c); if (out.length >= maxN) break; }
  return out.map(o => o.v).sort((a, b) => a - b);
}
function drawView(doc, vw, T, o) {
  const {bbox: bb} = vw, tp = (a, b) => pg(T, a, b);
  const x0 = tp(bb.a0, bb.b1)[0], x1 = tp(bb.a1, bb.b1)[0], yT = tp(bb.a0, bb.b1)[1], yB = tp(bb.a0, bb.b0)[1];
  // hatch + cut contour
  if (vw.cutLoops.length) {
    const L = vw.cutLoops.map(l => l.map(p => tp(p[0], p[1])));
    doc.setDrawColor(40); doc.setLineWidth(0.12);
    let mn = 1e18, mx = -1e18; L.forEach(l => l.forEach(p => { mn = Math.min(mn, p[0] + p[1]); mx = Math.max(mx, p[0] + p[1]); }));
    for (let k = mn + 1.5; k < mx; k += 2.4 * Math.SQRT2) {
      const xs = [];
      for (const l of L) for (let i = 0, j = l.length - 1; i < l.length; j = i++) { const a = l[i], b = l[j], fa = a[0] + a[1] - k, fb = b[0] + b[1] - k; if (fa * fb < 0) { const t = fa / (fa - fb); xs.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]); } }
      xs.sort((p, q) => p[0] - q[0]);
      for (let i = 0; i + 1 < xs.length; i += 2) doc.line(xs[i][0], xs[i][1], xs[i + 1][0], xs[i + 1][1]);
    }
    doc.setDrawColor(0); doc.setLineWidth(0.5);
    for (const l of L) doc.lines(l.slice(1).concat([l[0]]).map((p, i) => [p[0] - (i ? l[i][0] : l[0][0]), p[1] - (i ? l[i][1] : l[0][1])]), l[0][0], l[0][1], [1, 1], 'S', true);
  }
  // visible edges
  doc.setDrawColor(0); doc.setLineWidth(0.35);
  for (const pl of vw.polys) {
    const P = pl.pts.map(p => tp(p[0], p[1])); if (P.length < 2) continue;
    doc.lines(P.slice(1).map((p, i) => [p[0] - P[i][0], p[1] - P[i][1]]), P[0][0], P[0][1], [1, 1], 'S', pl.closed);
  }
  // centre lines
  doc.setLineWidth(0.15); doc.setDrawColor(0); doc.setLineDashPattern([6, 1.2, 1.2, 1.2], 0);
  { const cen = new Map(); for (const c of vw.circles) { const k = Math.round(c.cx / 0.3) + ',' + Math.round(c.cy / 0.3); const e = cen.get(k); if (!e) cen.set(k, {cx: c.cx, cy: c.cy, r: c.r}); else e.r = Math.max(e.r, c.r); }
    for (const c of cen.values()) { const [cx, cy] = tp(c.cx, c.cy), r = c.r * T.s + 3; doc.line(cx - r, cy, cx + r, cy); doc.line(cx, cy - r, cx, cy + r); } }
  for (const f of o.axisFeats || []) {
    const m = o.mapFeat(f); if (!m) continue;
    if (m.h) { const [xa, y] = tp(m.a - m.len / 2 - 3 / T.s, m.b), [xb] = tp(m.a + m.len / 2 + 3 / T.s, m.b); doc.line(xa, y, xb, y); }
    else { const [x, ya] = tp(m.a, m.b + m.len / 2 + 3 / T.s), [, yb] = tp(m.a, m.b - m.len / 2 - 3 / T.s); doc.line(x, ya, x, yb); }
  }
  doc.setLineDashPattern([], 0);
  // coordinate candidates
  const vC = [], hC = [];
  for (const l of vw.lines) {
    const dx = l.b[0] - l.a[0], dy = l.b[1] - l.a[1], len = Math.hypot(dx, dy); if (len < 2.5 || len < 0.12 * Math.min(bb.a1 - bb.a0, bb.b1 - bb.b0)) continue;
    if (Math.abs(dx) < 0.02 * len + 0.02) vC.push({v: (l.a[0] + l.b[0]) / 2, w: len, lo: Math.min(l.a[1], l.b[1]), hi: Math.max(l.a[1], l.b[1])});
    else if (Math.abs(dy) < 0.02 * len + 0.02) hC.push({v: (l.a[1] + l.b[1]) / 2, w: len, lo: Math.min(l.a[0], l.b[0]), hi: Math.max(l.a[0], l.b[0])});
  }
  for (const c of vw.circles) { vC.push({v: c.cx, w: 1e4 + c.r}); hC.push({v: c.cy, w: 1e4 + c.r}); }
  const midA = (bb.a0 + bb.a1) / 2, midB = (bb.b0 + bb.b1) / 2;
  // symmetry makes a mid-point dimension redundant (no 18.9 + 18.9 halves)
  const aList = pickCoords(vC, bb.a0, bb.a1, 5).filter(v => Math.abs(v - midA) > 0.35), bList = pickCoords(hC, bb.b0, bb.b1, 5).filter(v => Math.abs(v - midB) > 0.35);
  const fmt = (len) => fmtN(len);
  const seen = doc.__seen || (doc.__seen = new Set()), fresh = v => { const k = Math.round(v * 10); if (seen.has(k)) return false; seen.add(k); return true; };
  // horizontal chain + overall (below)
  let row = 0;
  if (aList.length && !o.noH) {
    const cs = [bb.a0, ...aList, bb.a1], yd = yB + 13;
    let skipH = -1; if (o.overallH) { let m = 0; for (let i = 0; i + 1 < cs.length; i++) if (cs[i + 1] - cs[i] > m) { m = cs[i + 1] - cs[i]; skipH = i; } }
    for (let i = 0; i + 1 < cs.length; i++) if (i !== skipH && cs[i + 1] - cs[i] > 2.2 && fresh(cs[i + 1] - cs[i])) { const xa = tp(cs[i], bb.b0)[0], xb = tp(cs[i + 1], bb.b0)[0]; dHor(doc, xa, yB, xb, yB, yd, fmt(cs[i + 1] - cs[i])); }
    row = 1;
  }
  if (o.overallH && fresh(bb.a1 - bb.a0)) dHor(doc, x0, yB, x1, yB, yB + 13 + row * 8, fmt(bb.a1 - bb.a0));
  // vertical chain (right) + overall (left)
  if (bList.length) {
    const cs = [bb.b0, ...bList, bb.b1], xd = x1 + 8;
    let skipV = -1; if (o.overallV || o.omitLargest) { let m = 0; for (let i = 0; i + 1 < cs.length; i++) if (cs[i + 1] - cs[i] > m) { m = cs[i + 1] - cs[i]; skipV = i; } }
    for (let i = 0; i + 1 < cs.length; i++) if (i !== skipV && cs[i + 1] - cs[i] > 2.2 && fresh(cs[i + 1] - cs[i])) { const ya = tp(bb.a1, cs[i])[1], yb = tp(bb.a1, cs[i + 1])[1]; dVer(doc, x1, ya, x1, yb, xd, fmt(cs[i + 1] - cs[i])); }
  }
  if (o.overallV && fresh(bb.b1 - bb.b0)) dVer(doc, x0, yT, x0, yB, x0 - 10, fmt(bb.b1 - bb.b0));
  // leaders: diameters and radii
  const shelf = x1 + 24; let sy = yT + 3;
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(0); doc.setDrawColor(0); doc.setLineWidth(0.15);
  const groups = new Map();
  for (const c of vw.circles) { const near = [...groups.keys()].find(q => q[0] === 'D' && Math.abs(parseFloat(q.slice(1)) - 2 * c.r) < 0.3); const k = near || 'D' + (2 * c.r).toFixed(1); const g = groups.get(k) || {n: 0, c, txt: '\u00D8' + fmtN(2 * c.r), kind: 'c'}; g.n++; groups.set(k, g); }
  const big = Math.max(bb.a1 - bb.a0, bb.b1 - bb.b0);
  for (const a of vw.arcs) { if (Math.abs(a.sweep) >= 2.2) { const k = 'D' + (2 * a.r).toFixed(1); if (!groups.has(k) && ![...groups.keys()].some(q => q[0] === 'D' && Math.abs(parseFloat(q.slice(1)) - 2 * a.r) < 0.3)) groups.set(k, {n: 1, c: a, txt: '\u00D8' + fmtN(2 * a.r), kind: 'c'}); } }
  for (const a of vw.arcs) { if (Math.abs(a.sweep) < 0.9 || Math.abs(a.sweep) >= 2.2 || a.r > 0.4 * big || a.r < 0.8) continue; const k = 'R' + a.r.toFixed(1); const g = groups.get(k) || {n: 0, c: a, txt: 'R' + fmtN(a.r), kind: 'a'}; g.n++; groups.set(k, g); }
  let drawn = 0;
  for (const [k, g] of groups) {
    if (drawn >= 7) break; if (!fresh(parseFloat(k.slice(1)))) continue; drawn++;
    const txt = (g.n > 1 ? g.n + '-' : '') + g.txt, [cx, cy] = tp(g.c.cx, g.c.cy), r = g.c.r * T.s;
    let px, py; if (g.kind === 'c') { const ang = (28 + 13 * (drawn - 1)) * Math.PI / 180; px = cx + r * Math.cos(ang); py = cy - r * Math.sin(ang); } else { [px, py] = tp(g.c.mid[0], g.c.mid[1]); }
    doc.line(px, py, shelf - 1, sy); const tw = doc.getTextWidth(txt); doc.line(shelf - 1, sy, shelf + tw + 1, sy); doc.text(txt, shelf, sy - 1); sy += 9;
    arrow(doc, px, py, (px - (shelf - 1)) / Math.hypot(px - shelf + 1, py - sy + 9) * -1 * -1, 0 * 1);
  }
  // angle dimensions between a slanted line and an axis-aligned line
  let angN = 0;
  for (const l of vw.lines) {
    if (angN >= 2) break;
    const dx = l.b[0] - l.a[0], dy = l.b[1] - l.a[1], len = Math.hypot(dx, dy); if (len < 4 || len < 0.15 * big) continue;
    const ang = Math.abs(Math.atan2(dy, dx)) * 180 / Math.PI, off = Math.min(ang % 90, 90 - (ang % 90)); if (off < 8) continue;
    for (const end of [l.a, l.b]) {
      const other = end === l.a ? l.b : l.a;
      const m = vw.lines.find(q => q !== l && [q.a, q.b].some(p => Math.hypot(p[0] - end[0], p[1] - end[1]) < 0.15) && (Math.abs(q.b[0] - q.a[0]) < 0.02 * q.len + 0.02 || Math.abs(q.b[1] - q.a[1]) < 0.02 * q.len + 0.02) && q.len > 3);
      if (!m) continue;
      const mo = Math.hypot(m.a[0] - end[0], m.a[1] - end[1]) < 0.15 ? m.b : m.a;
      const v1 = [other[0] - end[0], other[1] - end[1]], v2 = [mo[0] - end[0], mo[1] - end[1]];
      let a1 = Math.atan2(v1[1], v1[0]), a2 = Math.atan2(v2[1], v2[0]), da = a2 - a1; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
      const deg = Math.abs(da) * 180 / Math.PI; if (deg > 170 || deg < 5) continue;
      const [vx, vy] = tp(end[0], end[1]), rr = Math.min(9, len * T.s * 0.5); const pts = [];
      for (let i = 0; i <= 12; i++) { const t = a1 + da * i / 12; pts.push([vx + rr * Math.cos(t), vy - rr * Math.sin(t)]); }
      doc.setLineWidth(0.15); doc.lines(pts.slice(1).map((p, i) => [p[0] - pts[i][0], p[1] - pts[i][1]]), pts[0][0], pts[0][1], [1, 1], 'S', false);
      const tm = a1 + da / 2; doc.setFontSize(7.5); doc.text(fmtN(deg) + '\u00B0', vx + (rr + 1.5) * Math.cos(tm), vy - (rr + 1.5) * Math.sin(tm), {align: 'center'});
      angN++; break;
    }
  }
}

function drawSolidSheet(doc, r, cm) {
  const X = r.sz.x, Y = r.sz.y, Z = r.sz.z;
  const tris = trisOf(r.geom), feats = r.feats;
  // cut plane for the half-section: through the biggest hole / shaft axis that is parallel to Y or Z, otherwise the middle
  const axf = feats.filter(f => f.axis === 'y' || f.axis === 'z').sort((a, b) => (b.axis === 'y') - (a.axis === 'y') || b.d - a.d || Math.abs(a.c[0] - X / 2) - Math.abs(b.c[0] - X / 2))[0];
  doc.__seen = new Set();
  const front = buildView(tris, 'front'), top = buildView(tris, 'top');
  const mn = {x: front.bbox.a0, y: top.bbox.b0, z: front.bbox.b0};
  const xc = mn.x + (axf ? axf.c[0] : X / 2);
  const side = buildView(tris, 'left', {section: {axis: 0, val: xc}});
  const fit = s => X * s + Y * s <= 128 && (Y + Z) * s <= 198 && X * s <= 140;
  const sc = pickScale(fit), s = sc[0];
  doc.addPage(); frame(doc);
  // FIRST ANGLE: front view top-left, plan (top view) BELOW it, left view / section A-A to the RIGHT of it
  const fx = 40, fyT = 30, fyB = fyT + Z * s, tyT = fyB + 36, sx = fx + X * s + 60;
  const Tf = {ox: fx, oy: fyB, s, a0: front.bbox.a0, b1: front.bbox.b1};
  const Tt = {ox: fx, oy: tyT + Y * s, s, a0: top.bbox.a0, b1: top.bbox.b1};
  const Ts = {ox: sx, oy: fyB, s, a0: side ? side.bbox.a0 : 0, b1: side ? side.bbox.b1 : 0};
  const rel = f => [f.c[0] + mn.x, f.c[1] + mn.y, f.c[2] + mn.z];
  drawView(doc, front, Tf, {overallH: true, overallV: true, axisFeats: feats.filter(f => f.axis === 'x' || f.axis === 'z'), mapFeat: f => { const c = rel(f); return f.axis === 'x' ? {h: true, a: c[0], b: c[2], len: f.len} : {h: false, a: c[0], b: c[2], len: f.len}; }});
  drawView(doc, top, Tt, {overallH: false, overallV: true, axisFeats: feats.filter(f => f.axis === 'x' || f.axis === 'y'), mapFeat: f => { const c = rel(f); return f.axis === 'x' ? {h: true, a: c[0], b: c[1], len: f.len} : {h: false, a: c[0], b: c[1], len: f.len}; }});
  if (side) drawView(doc, side, Ts, {overallH: false, overallV: false, noH: true, omitLargest: true, axisFeats: feats.filter(f => (f.axis === 'y' || f.axis === 'z') && Math.abs(rel(f)[0] - xc) <= f.d / 2), mapFeat: f => { const c = rel(f); return f.axis === 'y' ? {h: true, a: -c[1], b: c[2], len: f.len} : {h: false, a: -c[1], b: c[2], len: f.len}; }});
  // cutting-plane marks on the front view; the arrows show the viewing direction (towards the right, i.e. looking at the part from its left side)
  { const [xp, ya] = pg(Tf, xc, front.bbox.b1), [, yb] = pg(Tf, xc, front.bbox.b0);
    doc.setDrawColor(0); doc.setLineWidth(0.5); doc.line(xp, ya - 7, xp, ya - 2); doc.line(xp, yb + 2, xp, yb + 6);
    doc.setLineWidth(0.15); doc.setLineDashPattern([6, 1.2, 1.2, 1.2], 0); doc.line(xp, ya - 2, xp, yb + 2); doc.setLineDashPattern([], 0);
    arrow(doc, xp + 5, ya - 6, 1, 0); arrow(doc, xp + 5, yb + 6, 1, 0); doc.line(xp, ya - 6, xp + 5, ya - 6); doc.line(xp, yb + 6, xp + 5, yb + 6);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(0); doc.text('A', xp - 4, ya - 5); doc.text('A', xp - 4, yb + 8.5);
    if (side) { const [sxp, syp] = pg(Ts, side.bbox.a0, side.bbox.b1); doc.text('SECTION A-A', sxp, syp - 8); } }
  // iso, top right
  { const bx = 262, by = 16, bw = 143, bh = 88, dd = Math.hypot(X, Y, Z), isoS = Math.min(bw, bh) / dd * 0.92;
    const w = bw / isoS, h = bh / isoS;
    doc.addImage(view(r.geom, r.box, [1, -1.25, 0.9], [0, 0, 1], w, h, Math.min(14, 1400 / Math.max(w, h)), true), 'JPEG', bx, by, bw, bh); }
  const sets = [...new Set(feats.map(f => f.d.toFixed(1)))].slice(0, 5).map(v => '\u00D8' + v).join(', ');
  titleBlock(doc, {...cm, scale: sc[1], proj: 'FIRST ANGLE', notes: ['1. ALL DIMENSIONS ARE IN MILLIMETERS.', `2. OVERALL SIZE ${f1(X)} x ${f1(Y)} x ${f1(Z)} mm, VOLUME ${(r.vol / 1000).toFixed(2)} cm3.`,
    `3. HOLE / SHAFT DIAMETERS: ${sets || 'none found'}${feats.length ? ` (${feats.length} features)` : ''}.`, '4. SIZES ARE READ FROM THE 3D MODEL (+/-0.1 mm).', feats.length ? '5. FEATURE TABLE WITH POSITIONS ON NEXT SHEET.' : '5. MATERIAL AND TOLERANCES NOT SPECIFIED.']});
}
