// Vector engineering views of a solid part: visible edges, circles / arcs / lines, and a half-section with hatch loops.
import * as THREE from 'three';

export const VIEWS = {
  front: {c: [0, -1, 0], r: [1, 0, 0], u: [0, 0, 1]},
  top:   {c: [0, 0, 1],  r: [1, 0, 0], u: [0, 1, 0]},
  side:  {c: [1, 0, 0],  r: [0, 1, 0], u: [0, 0, 1]},       // seen from the right (third angle)
  left:  {c: [-1, 0, 0], r: [0, -1, 0], u: [0, 0, 1]}       // seen from the left (first angle puts it right of the front view)
};
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

export function trisOf(geom) {
  const p = geom.attributes.position, ix = geom.index, n = ix ? ix.count : p.count, out = [];
  const P = i => [p.getX(i), p.getY(i), p.getZ(i)], fo = geom.userData && geom.userData.faceOf;
  for (let i = 0; i < n; i += 3) { const t = ix ? [P(ix.getX(i)), P(ix.getX(i + 1)), P(ix.getX(i + 2))] : [P(i), P(i + 1), P(i + 2)]; t.f = fo ? fo[i / 3] : -1; out.push(t); }
  return out;
}

// keep the part of the mesh where p[axis] <= val; returns clipped triangles and the cut segments lying in the plane
export function clipMesh(tris, axis, val, dir = 1) {
  const out = [], cut = [];
  for (const t of tris) {
    const d = t.map(p => dir * (val - p[axis]));
    if (d.every(v => v >= -1e-9)) { out.push(t); continue; }
    if (d.every(v => v <= 1e-9)) continue;
    const poly = [], pts = [];
    for (let i = 0; i < 3; i++) {
      const a = t[i], b = t[(i + 1) % 3], da = d[i], db = d[(i + 1) % 3];
      if (da >= 0) poly.push(a);
      if ((da > 1e-9 && db < -1e-9) || (da < -1e-9 && db > 1e-9)) { const k = da / (da - db), q = [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k]; q[axis] = val; poly.push(q); pts.push(q); }
    }
    for (let i = 1; i + 1 < poly.length; i++) { const nt = [poly[0], poly[i], poly[i + 1]]; nt.f = t.f; out.push(nt); }
    // tri touching the plane along an edge also produces a cut segment
    const on = t.filter(p => Math.abs(p[axis] - val) < 1e-7);
    if (pts.length === 2) cut.push(pts); else if (pts.length === 1 && on.length === 1) cut.push([pts[0], on[0]]); else if (on.length === 2 && d.some(v => v > 1e-9)) cut.push(on);
  }
  return {tris: out, cut};
}

// ---------- edges (feature + silhouette + boundary) ----------
function edgesOf(tris, c) {
  const map = new Map(), V = [], key = p => Math.round(p[0] / 0.005) + ',' + Math.round(p[1] / 0.005) + ',' + Math.round(p[2] / 0.005);
  const id = p => { const k = key(p); let i = map.get(k); if (i === undefined) { i = V.length; V.push(p); map.set(k, i); } return i; };
  const T = [], N = [], F = [];
  for (const t of tris) {
    const a = id(t[0]), b = id(t[1]), cc = id(t[2]); if (a === b || b === cc || a === cc) continue;
    const n = cross(sub(V[b], V[a]), sub(V[cc], V[a])), l = Math.hypot(n[0], n[1], n[2]); if (l < 1e-12) continue;
    T.push([a, b, cc]); N.push([n[0] / l, n[1] / l, n[2] / l]); F.push(t.f === undefined ? -1 : t.f);
  }
  const E = new Map();
  T.forEach((t, i) => { for (let k = 0; k < 3; k++) { const a = t[k], b = t[(k + 1) % 3], kk = a < b ? a * 4194304 + b : b * 4194304 + a; const e = E.get(kk); if (e) e.t.push(i); else E.set(kk, {a, b, t: [i]}); } });
  const out = [], CF = Math.cos(28 * Math.PI / 180), CT = Math.cos(8 * Math.PI / 180);
  for (const e of E.values()) {
    let kind = null;
    if (e.t.length === 1) kind = 'b';
    else if (e.t.length > 2) kind = 'f';
    else {
      const n1 = N[e.t[0]], n2 = N[e.t[1]];
      const f1 = F[e.t[0]], f2 = F[e.t[1]], dd = dot(n1, n2);
      if (f1 >= 0 && f2 >= 0) { if (f1 !== f2 && dd < CT) kind = 'f'; }
      else if (dd < CF) kind = 'f';
      if (kind === 'f') { /* real edge */ }
      if (!kind) { const s1 = dot(n1, c), s2 = dot(n2, c), z1 = Math.abs(s1) <= 1e-6, z2 = Math.abs(s2) <= 1e-6; if ((!z1 && !z2 && s1 * s2 < 0) || (z1 !== z2)) kind = 's'; }
    }
    if (kind) out.push([V[e.a], V[e.b], kind, e.a, e.b]);
  }
  return out;
}

// ---------- depth map for visibility ----------
let R2 = null;
function getR2() {
  if (R2) return R2;
  const renderer = new THREE.WebGLRenderer({antialias: false, preserveDrawingBuffer: true});
  renderer.setPixelRatio(1); renderer.setClearColor(0xffffff, 1);
  R2 = {renderer, scene: new THREE.Scene(), cam: new THREE.OrthographicCamera(-1, 1, 1, -1, -1e6, 1e6)};
  return R2;
}
function depthMap(tris, V, fr, ppm, dmin, range) {
  const {renderer, scene, cam} = getR2();
  const W = Math.max(8, Math.ceil((fr.a1 - fr.a0) * ppm)), H = Math.max(8, Math.ceil((fr.b1 - fr.b0) * ppm));
  renderer.setSize(W, H, false);
  const pos = new Float32Array(tris.length * 9); let o = 0;
  for (const t of tris) for (const p of t) { pos[o++] = p[0]; pos[o++] = p[1]; pos[o++] = p[2]; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.ShaderMaterial({
    side: THREE.DoubleSide, uniforms: {uC: {value: new THREE.Vector3(...V.c)}, uMin: {value: dmin}, uRange: {value: range}},
    vertexShader: 'uniform vec3 uC; uniform float uMin; uniform float uRange; varying float vT; void main(){ vT = 1.0 - (dot(position, uC) - uMin) / uRange; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: 'varying float vT; void main(){ float t = clamp(vT, 0.0, 0.99999); vec3 e = fract(t * vec3(1.0, 255.0, 65025.0)); e -= e.yzz * vec3(1.0/255.0, 1.0/255.0, 0.0); gl_FragColor = vec4(e, 1.0); }'
  });
  const m = new THREE.Mesh(g, mat); scene.add(m);
  const ac = (fr.a0 + fr.a1) / 2, bc = (fr.b0 + fr.b1) / 2, ctr = new THREE.Vector3(V.r[0] * ac + V.u[0] * bc, V.r[1] * ac + V.u[1] * bc, V.r[2] * ac + V.u[2] * bc);
  cam.up.set(...V.u); cam.position.copy(ctr).addScaledVector(new THREE.Vector3(...V.c), 1e4); cam.lookAt(ctr);
  cam.left = -(fr.a1 - fr.a0) / 2; cam.right = (fr.a1 - fr.a0) / 2; cam.top = (fr.b1 - fr.b0) / 2; cam.bottom = -(fr.b1 - fr.b0) / 2; cam.updateProjectionMatrix(); cam.updateMatrixWorld(true);
  renderer.render(scene, cam);
  const gl = renderer.getContext(), buf = new Uint8Array(W * H * 4); gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf);
  scene.remove(m); g.dispose(); mat.dispose();
  return {W, H, buf};
}

// ---------- 2D chain / fit ----------
function chain(segs, tol = 0.02) {
  const map = new Map(), k = p => Math.round(p[0] / tol) + ',' + Math.round(p[1] / tol);
  const ends = segs.map(s => [k(s[0]), k(s[1])]);
  ends.forEach((e, i) => { for (const kk of e) (map.get(kk) || map.set(kk, []).get(kk)).push(i); });
  const used = new Uint8Array(segs.length), out = [];
  const grow = (pl, endKey, front) => {
    for (let g = 0; g < 1e6; g++) {
      const lst = map.get(endKey); if (!lst || lst.length !== 2) return false;
      const ni = lst.find(i => !used[i]); if (ni === undefined) return endKey === (front ? k(pl[pl.length - 1]) : k(pl[0]));
      used[ni] = 1; const [ka] = ends[ni], s = segs[ni], fw = ka === endKey, nx = fw ? s[1] : s[0], nk = fw ? ends[ni][1] : ends[ni][0];
      if (front) pl.unshift(nx); else pl.push(nx);
      endKey = nk;
    }
    return false;
  };
  for (let i = 0; i < segs.length; i++) {
    if (used[i]) continue; used[i] = 1;
    const pl = [segs[i][0], segs[i][1]];
    grow(pl, ends[i][1], false); const closed0 = k(pl[0]) === k(pl[pl.length - 1]);
    if (!closed0) grow(pl, ends[i][0], true);
    out.push({pts: pl, closed: k(pl[0]) === k(pl[pl.length - 1]) && pl.length > 3});
  }
  return out;
}
function fitCircle(P) {
  let sx = 0, sy = 0; P.forEach(p => { sx += p[0]; sy += p[1]; }); const mx = sx / P.length, my = sy / P.length;
  let suu = 0, svv = 0, suv = 0, suuu = 0, svvv = 0, suvv = 0, svuu = 0;
  for (const p of P) { const u = p[0] - mx, v = p[1] - my; suu += u * u; svv += v * v; suv += u * v; suuu += u * u * u; svvv += v * v * v; suvv += u * v * v; svuu += v * u * u; }
  const det = suu * svv - suv * suv; if (Math.abs(det) < 1e-12) return null;
  const A = (suuu + suvv) / 2, B = (svvv + svuu) / 2, uc = (A * svv - B * suv) / det, vc = (B * suu - A * suv) / det;
  const cx = uc + mx, cy = vc + my, r = Math.sqrt(uc * uc + vc * vc + (suu + svv) / P.length);
  let dev = 0; for (const p of P) dev = Math.max(dev, Math.abs(Math.hypot(p[0] - cx, p[1] - cy) - r));
  return {cx, cy, r, dev};
}
function classify(poly) {
  const res = {circles: [], arcs: [], lines: []};
  const P = poly.pts, n = P.length; if (n < 2) return res;
  const turn = (a, b, c) => { const v1 = [b[0] - a[0], b[1] - a[1]], v2 = [c[0] - b[0], c[1] - b[1]]; const l = Math.hypot(...v1) * Math.hypot(...v2); if (l < 1e-12) return 0; return Math.abs(Math.atan2(v1[0] * v2[1] - v1[1] * v2[0], v1[0] * v2[0] + v1[1] * v2[1])); };
  if (poly.closed && n >= 7) { const f0 = fitCircle(P.slice(0, -1)); if (f0 && f0.r > 0.3 && f0.r < 5000 && f0.dev <= 0.015 * f0.r + 0.02) { let sw = 0; const an = p => Math.atan2(p[1] - f0.cy, p[0] - f0.cx); for (let i = 1; i < n; i++) { let d = an(P[i]) - an(P[i - 1]); while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; sw += d; } if (Math.abs(sw) > 6) { res.circles.push({cx: f0.cx, cy: f0.cy, r: f0.r}); return res; } } }
  const cuts = [];
  for (let i = 1; i < n - 1; i++) if (turn(P[i - 1], P[i], P[i + 1]) > 0.44) cuts.push(i);
  if (poly.closed) { const a = turn(P[n - 2], P[0], P[1]); if (a > 0.44) cuts.push(0); }
  let pieces = [];
  if (poly.closed && !cuts.length) pieces.push({pts: P.slice(0, -1), full: true});
  else if (poly.closed) { const rot = cuts[0]; const Q = P.slice(0, -1); const R = Q.slice(rot).concat(Q.slice(0, rot), [Q[rot]]); const cs = []; for (let i = 1; i < R.length - 1; i++) if (turn(R[i - 1], R[i], R[i + 1]) > 0.44) cs.push(i); let s = 0; for (const c of cs.concat([R.length - 1])) { pieces.push({pts: R.slice(s, c + 1)}); s = c; } }
  else { let s = 0; for (const c of cuts.concat([n - 1])) { pieces.push({pts: P.slice(s, c + 1)}); s = c; } }
  for (const pc of pieces) {
    const q = pc.pts; if (q.length < 2) continue;
    const len = q.reduce((a, p, i) => i ? a + Math.hypot(p[0] - q[i - 1][0], p[1] - q[i - 1][1]) : 0, 0);
    if (pc.full || q.length >= 4) {
      const f = fitCircle(q);
      if (f && f.r > 0.3 && f.r < 5000 && f.dev <= 0.02 * f.r + 0.03) {
        if (pc.full) { res.circles.push({cx: f.cx, cy: f.cy, r: f.r}); continue; }
        const ang = p => Math.atan2(p[1] - f.cy, p[0] - f.cx); let sw = 0; for (let i = 1; i < q.length; i++) { let d = ang(q[i]) - ang(q[i - 1]); while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; sw += d; }
        const chord = Math.hypot(q[q.length - 1][0] - q[0][0], q[q.length - 1][1] - q[0][1]);
        if (Math.abs(sw) > 0.17 && !(chord > 0 && len / chord < 1.003)) { res.arcs.push({cx: f.cx, cy: f.cy, r: f.r, a0: ang(q[0]), sweep: sw, mid: q[Math.floor(q.length / 2)], pts: q}); continue; }
      }
    }
    // straight pieces: merge near-collinear runs into one segment
    res.lines.push({a: q[0], b: q[q.length - 1], len});
  }
  return res;
}

// Join open line pieces that continue each other across a short gap (same direction, small sideways offset): removes dash patterns.
function bridgeGaps(polys, maxGap) {
  const tan = (pts, atEnd) => { const n = pts.length, a = atEnd ? pts[n - 1] : pts[0]; let b = null, acc = 0;
    for (let i = 1; i < n; i++) { const q = atEnd ? pts[n - 1 - i] : pts[i]; acc = Math.hypot(q[0] - a[0], q[1] - a[1]); b = q; if (acc >= 0.8) break; }
    const l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; return [(a[0] - b[0]) / l * (atEnd ? 1 : 1), (a[1] - b[1]) / l]; };  // direction pointing OUT of the piece
  let list = polys.map(p => ({pts: p.pts.slice(), closed: p.closed}));
  for (let round = 0; round < 200; round++) {
    let best = null;
    const open = list.map((p, i) => ({p, i})).filter(o => !o.p.closed && o.p.pts.length >= 2);
    for (let x = 0; x < open.length; x++) for (let y = 0; y < open.length; y++) {
      if (x === y) continue;
      const P = open[x].p, Q = open[y].p;                              // join P.end -> Q.start
      const a = P.pts[P.pts.length - 1], b = Q.pts[0], d = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (d < 0.02 || d > maxGap) continue;
      const tp = tan(P.pts, true), tq = tan(Q.pts, false), u = [(b[0] - a[0]) / d, (b[1] - a[1]) / d];
      const c1 = tp[0] * u[0] + tp[1] * u[1], c2 = -(tq[0] * u[0] + tq[1] * u[1]);          // both must point along the gap
      if (c1 < 0.992 || c2 < 0.992) continue;                           // within ~7 degrees
      if (!best || d < best.d) best = {d, x: open[x].i, y: open[y].i};
    }
    if (!best) break;
    const P = list[best.x], Q = list[best.y];
    P.pts = P.pts.concat(Q.pts); list.splice(best.y, 1);
  }
  return list;
}
export function polyInside(loops, p) {                      // even-odd
  let c = false;
  for (const l of loops) for (let i = 0, j = l.length - 1; i < l.length; j = i++) {
    const a = l[i], b = l[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}

// main entry. opts.section = {axis, val} cuts the part at p[axis] = val and keeps the side away from the camera.
export function buildView(tris, viewKey, opts = {}) {
  const V = VIEWS[viewKey];
  let list = tris, cutLoops = [], vEff = 0;
  if (opts.section) {
    const dirS = V.c[opts.section.axis] > 0 ? 1 : -1; vEff = opts.section.val + dirS * 0.0137;   // camera on the + side keeps <= val, on the - side keeps >= val
    const cl = clipMesh(tris, opts.section.axis, vEff, dirS);
    list = cl.tris;
    { const seen = new Set(), kq = p => Math.round(p[0] / 0.004) + ',' + Math.round(p[1] / 0.004), cs = [];
      for (const s of cl.cut) { const a = [dot(s[0], V.r), dot(s[0], V.u)], b = [dot(s[1], V.r), dot(s[1], V.u)], ka = kq(a), kb = kq(b); if (ka === kb) continue; const k = ka < kb ? ka + '|' + kb : kb + '|' + ka; if (seen.has(k)) continue; seen.add(k); cs.push([a, b]); }
      cutLoops = chain(cs, 0.004).filter(c => c.closed).map(c => c.pts);
      if (!cutLoops.length && cs.length) cutLoops = chain(cs, 0.02).filter(c => c.closed).map(c => c.pts); }
  }
  if (!list.length) return null;
  let a0 = 1e18, a1 = -1e18, b0 = 1e18, b1 = -1e18, d0 = 1e18, d1 = -1e18;
  for (const t of list) for (const p of t) { const a = dot(p, V.r), b = dot(p, V.u), d = dot(p, V.c); a0 = Math.min(a0, a); a1 = Math.max(a1, a); b0 = Math.min(b0, b); b1 = Math.max(b1, b); d0 = Math.min(d0, d); d1 = Math.max(d1, d); }
  const bbox = {a0, a1, b0, b1};
  const pad = 0.5, fr = {a0: a0 - pad, a1: a1 + pad, b0: b0 - pad, b1: b1 + pad};
  const ppm = Math.min(12, 2200 / Math.max(fr.a1 - fr.a0, fr.b1 - fr.b0, 1)), range = Math.max(d1 - d0, 1e-3);
  const dm = depthMap(list, V, fr, ppm, d0, range);
  const decode = (x, y) => { x = Math.min(dm.W - 1, Math.max(0, x)); y = Math.min(dm.H - 1, Math.max(0, y)); const o = ((dm.H - 1 - y) * dm.W + x) * 4; return dm.buf[o] / 255 + dm.buf[o + 1] / 65025 + dm.buf[o + 2] / 16581375; };
  const eps = Math.max(0.3, 4 / ppm) / range;
  const edges = edgesOf(list, V.c).filter(e => !(e[2] === 'b' && opts.section && Math.abs(e[0][opts.section.axis] - vEff) < 1e-5 && Math.abs(e[1][opts.section.axis] - vEff) < 1e-5));
  const vis = [];
  // chain mesh edges into whole 3D curves, then test visibility along each curve (so small gaps close and fragments vanish)
  const adj = new Map(); edges.forEach((e, i) => { for (const v of [e[3], e[4]]) (adj.get(v) || adj.set(v, []).get(v)).push(i); });
  const usedE = new Uint8Array(edges.length), curves = [];
  const walk = (start, ei) => {
    const pts = [edges[ei][3] === start ? edges[ei][0] : edges[ei][1]]; let cur = start, e = ei;
    for (let g = 0; g < 1e6; g++) { usedE[e] = 1; const E = edges[e], nxt = E[3] === cur ? E[4] : E[3], np = E[3] === cur ? E[1] : E[0]; pts.push(np); cur = nxt; const l = adj.get(cur); if (l.length !== 2) break; const ne = l.find(i => !usedE[i]); if (ne === undefined) break; e = ne; }
    return pts;
  };
  for (const [v, l] of adj) if (l.length !== 2) for (const ei of l) if (!usedE[ei]) curves.push(walk(v, ei));
  edges.forEach((e, i) => { if (!usedE[i]) curves.push(walk(e[3], i)); });
  for (const C of curves) {
    const A2 = C.map(p => [dot(p, V.r), dot(p, V.u), 1 - (dot(p, V.c) - d0) / range]);
    const S = [], D = [0];                                     // samples [a,b,te], cumulative distance
    S.push(A2[0]);
    for (let j = 0; j + 1 < A2.length; j++) {
      const P0 = A2[j], P1 = A2[j + 1], Lj = Math.hypot(P1[0] - P0[0], P1[1] - P0[1]); if (Lj < 1e-5) continue;
      const nj = Math.max(1, Math.min(200, Math.ceil(Lj * ppm / 2)));
      for (let k = 1; k <= nj; k++) { const f = k / nj, q = [P0[0] + (P1[0] - P0[0]) * f, P0[1] + (P1[1] - P0[1]) * f, P0[2] + (P1[2] - P0[2]) * f]; D.push(D[D.length - 1] + Lj / nj); S.push(q); }
    }
    const n = S.length - 1; if (n < 1) continue;
    const vs = new Array(n + 1);
    for (let i = 0; i <= n; i++) {
      const px = Math.round((S[i][0] - fr.a0) * ppm), py = Math.round((fr.b1 - S[i][1]) * ppm);
      let tb = 0; for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) { if (Math.abs(dx) + Math.abs(dy) > 3) continue; const v = decode(px + dx, py + dy); if (v > tb) tb = v; }
      vs[i] = S[i][2] <= tb + eps;
    }
    const total = D[n], closedC = Math.hypot(S[0][0] - S[n][0], S[0][1] - S[n][1]) < 1e-4;
    // close dash patterns: a hidden gap shorter than 0.7 mm, or shorter than 3 mm with a visible run at least as long on each side, is a depth-test flicker
    { const gaps = []; for (let i = 0; i <= n; i++) if (!vs[i]) { let j = i; while (j <= n && !vs[j]) j++; gaps.push([i, j]); i = j; }
      for (let gi = 0; gi < gaps.length; gi++) { const [i, j] = gaps[gi]; if (i === 0 || j > n) continue;
        const gl = D[j] - D[i - 1];
        let lenL = 0; { let k = i - 1; while (k >= 0 && vs[k]) k--; lenL = D[i - 1] - D[Math.max(k + 1, 0)]; }
        let lenR = 0; { let k = j; while (k <= n && vs[k]) k++; lenR = D[Math.min(k - 1, n)] - D[j]; }
        if (gl <= 0.7 || (gl <= 3 && lenL >= gl && lenR >= gl)) for (let q = i; q < j; q++) vs[q] = true; } }
    const minRun = total < 1 ? 0 : 0.6;
    for (let i = 0; i <= n; i++) {
      if (!vs[i]) continue; let j = i; while (j + 1 <= n && vs[j + 1]) j++;
      if (D[j] - D[i] >= minRun || (i === 0 && j === n)) { const pl = []; for (let q = i; q <= j; q++) pl.push([S[q][0], S[q][1]]); if (pl.length >= 2) vis.push([pl, null, S[i][2]]); }
      i = j;
    }
  }
  vis.sort((x, y) => x[2] - y[2]);
  let segs = [];
  { const G = 0.04, cells = new Set(), ck = (x, y) => Math.round(x / G) + ',' + Math.round(y / G);
    const covered = (x, y) => { const cx = Math.round(x / G), cy = Math.round(y / G); for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) if (cells.has((cx + i) + ',' + (cy + j))) return true; return false; };
    for (const [pl] of vis) {
      // dense samples along the polyline (original vertices are flagged)
      const Q = [];
      for (let j = 0; j < pl.length; j++) {
        if (j === 0) { Q.push({x: pl[0][0], y: pl[0][1], v: true}); continue; }
        const A = pl[j - 1], B = pl[j], L = Math.hypot(B[0] - A[0], B[1] - A[1]), n = Math.max(1, Math.ceil(L / 0.05));
        for (let k = 1; k <= n; k++) { const f = k / n; Q.push({x: A[0] + (B[0] - A[0]) * f, y: A[1] + (B[1] - A[1]) * f, v: k === n}); }
      }
      const cum = [0]; for (let i = 1; i < Q.length; i++) cum.push(cum[i - 1] + Math.hypot(Q[i].x - Q[i - 1].x, Q[i].y - Q[i - 1].y));
      const tot = cum[cum.length - 1]; if (tot < 0.01) continue;
      const cov = Q.map(q => covered(q.x, q.y));
      let lo = 0; while (lo < Q.length - 1 && cum[lo] < 0.2) lo++; let hi = Q.length - 1; while (hi > 0 && tot - cum[hi] < 0.2) hi--;
      if (lo <= hi) { for (let i = 0; i < lo; i++) cov[i] = cov[lo]; for (let i = hi + 1; i < Q.length; i++) cov[i] = cov[hi]; } else { const m = cov[Q.length >> 1]; cov.fill(m); }
      let st = -1;
      const flush = (i0, i1) => { const pts = [[Q[i0].x, Q[i0].y]]; for (let i = i0 + 1; i < i1; i++) if (Q[i].v) pts.push([Q[i].x, Q[i].y]); if (i1 > i0) pts.push([Q[i1].x, Q[i1].y]); for (let i = 0; i + 1 < pts.length; i++) if (Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) > 0.01) segs.push([pts[i], pts[i + 1]]); };
      for (let i = 0; i < Q.length; i++) { if (!cov[i]) { if (st < 0) st = i; } else if (st >= 0) { flush(st, i - 1); st = -1; } }
      if (st >= 0) flush(st, Q.length - 1);
      for (const q of Q) cells.add(ck(q.x, q.y));
    } }
  if (opts.section && cutLoops.length) segs = segs.filter(s => !polyInside(cutLoops, [(s[0][0] + s[1][0]) / 2, (s[0][1] + s[1][1]) / 2]));
  { const seen = new Set(), kk = p => Math.round(p[0] / 0.03) + ',' + Math.round(p[1] / 0.03); segs = segs.filter(sg => { const a = kk(sg[0]), b = kk(sg[1]), k = a < b ? a + '|' + b : b + '|' + a; if (a === b || seen.has(k)) return false; seen.add(k); return true; }); }
  let polys = chain(segs, 0.03);
  { const plen = p => p.pts.reduce((t, q, i) => i ? t + Math.hypot(q[0] - p.pts[i - 1][0], q[1] - p.pts[i - 1][1]) : 0, 0);
    polys = polys.filter(p => plen(p) >= 1.0);
    polys = bridgeGaps(polys, 8); } if (globalThis.__dbg) console.log("DBG", edges.length, vis.length, segs.length, polys.length, ppm, range, eps);
  const circles = [], arcs = [], lines = [];
  // near-identical concentric full circles (e.g. several rim edges 0.1-0.4 mm apart) become one line: keep the outermost
  { const info = polys.map(p => ({p, c: classify(p)})), full = info.filter(o => o.c.circles.length === 1 && o.p.closed).sort((a, b) => b.c.circles[0].r - a.c.circles[0].r);
    const keep = [], drop = new Set();
    for (const o of full) { const c = o.c.circles[0]; if (keep.some(k => Math.hypot(k.cx - c.cx, k.cy - c.cy) < 0.4 && Math.abs(k.r - c.r) < 0.45)) drop.add(o); else keep.push(c); }
    polys = info.filter(o => !drop.has(o)).map(o => o.p);
    for (const o of info) { if (drop.has(o)) continue; circles.push(...o.c.circles); arcs.push(...o.c.arcs); lines.push(...o.c.lines); } }
  { const gk = new Map(); arcs.forEach((a, i) => { const k = Math.round(a.cx / 0.1) + ',' + Math.round(a.cy / 0.1) + ',' + Math.round(a.r / 0.1); (gk.get(k) || gk.set(k, []).get(k)).push(i); });
    const drop = new Set();
    for (const ids of gk.values()) { const sw = ids.reduce((t, i) => t + Math.abs(arcs[i].sweep), 0); if (sw >= 5.6) { circles.push({cx: arcs[ids[0]].cx, cy: arcs[ids[0]].cy, r: arcs[ids[0]].r}); ids.forEach(i => drop.add(i)); } }
    if (drop.size) { const keep = arcs.filter((_, i) => !drop.has(i)); arcs.length = 0; arcs.push(...keep); } }
  const dedupe = (arr, f) => { const seen = new Set(), out = []; for (const x of arr) { const k = f(x); if (!seen.has(k)) { seen.add(k); out.push(x); } } return out; };
  return {V, bbox, polys, circles: dedupe(circles, c => `${c.cx.toFixed(1)},${c.cy.toFixed(1)},${c.r.toFixed(1)}`), arcs: dedupe(arcs, c => `${c.cx.toFixed(1)},${c.cy.toFixed(1)},${c.r.toFixed(1)},${c.a0.toFixed(1)}`), lines, cutLoops};
}
